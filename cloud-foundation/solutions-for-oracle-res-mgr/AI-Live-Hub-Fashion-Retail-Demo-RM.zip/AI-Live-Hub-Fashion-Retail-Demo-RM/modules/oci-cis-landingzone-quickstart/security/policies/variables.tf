# Copyright © 2022, Oracle and/or its affiliates.
# All rights reserved. Licensed under the Universal Permissive License (UPL), Version 1.0 as shown at https://oss.oracle.com/licenses/upl.

variable "policies" {
  type = map(object({
    compartment_id = string  
    description    = string,
    statements     = list(string)
  }))
}