from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_session import Session
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
import uuid
import json
import markdown
import yaml
import oracledb

from config import Config
from db_connection import get_mongo_db, get_oracle_connection, oracle_env_configured

app = Flask(__name__)
app.config.from_object("config.Config")

# Session configuration
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_PERMANENT"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=2)
Session(app)

# =========================================================
# DATABASE CONNECTIONS
# =========================================================

mongo_db = get_mongo_db()

USE_DOCUMENT_BACKEND = Config.DOCUMENT_BACKEND in ("oracle_api", "atlas")

customers_collection = mongo_db["customer_profile"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
app_users_collection = mongo_db["app_users"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
shopping_cart_collection = mongo_db["shopping_cart"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
chat_history_collection = mongo_db["chat_history"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None


def document_store_enabled():
    return mongo_db is not None and customers_collection is not None


def document_users_enabled():
    return mongo_db is not None and app_users_collection is not None


def document_cart_enabled():
    return mongo_db is not None and shopping_cart_collection is not None


def document_chat_enabled():
    return mongo_db is not None and chat_history_collection is not None


oracle_available = False
if oracle_env_configured():
    try:
        startup_conn = get_oracle_connection()
        startup_cursor = startup_conn.cursor()
        startup_cursor.execute("select user from dual")
        startup_cursor.fetchone()
        startup_cursor.close()
        startup_conn.close()
        oracle_available = True
    except Exception as e:
        print(f"Startup Oracle test failed: {e}")
        oracle_available = False

if document_store_enabled():
    print("Startup Mongo-compatible test: customer_profile/app_users/shopping_cart/chat_history available")
else:
    print("Startup Mongo-compatible test: document backend disabled or unavailable")

# =========================================================
# DEMO PRODUCTS
# =========================================================

PRODUCTS = {
    "men": [
        {"id": 1, "name": "Classic Denim Jacket", "price": 89.99, "category": "men", "image": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500"},
        {"id": 2, "name": "Cotton Polo Shirt", "price": 45.99, "category": "men", "image": "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=500"},
        {"id": 3, "name": "Slim Fit Chinos", "price": 65.99, "category": "men", "image": "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500"},
        {"id": 4, "name": "Leather Sneakers", "price": 120.00, "category": "men", "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500"},
    ],
    "women": [
        {"id": 5, "name": "Floral Summer Dress", "price": 79.99, "category": "women", "image": "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=500"},
        {"id": 6, "name": "Cashmere Sweater", "price": 95.00, "category": "women", "image": "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500"},
        {"id": 7, "name": "High-Waist Jeans", "price": 72.50, "category": "women", "image": "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500"},
        {"id": 8, "name": "Ankle Boots", "price": 135.00, "category": "women", "image": "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500"},
    ],
    "kids": [
        {"id": 9, "name": "Kids Graphic Tee", "price": 24.99, "category": "kids", "image": "https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?w=500"},
        {"id": 10, "name": "Denim Overalls", "price": 42.00, "category": "kids", "image": "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=500"},
        {"id": 11, "name": "Colorful Sneakers", "price": 55.00, "category": "kids", "image": "https://images.unsplash.com/photo-1514989940723-e8e51635b782?w=500"},
        {"id": 12, "name": "Winter Jacket", "price": 68.00, "category": "kids", "image": "https://images.unsplash.com/photo-1578932750294-f5075e85f44a?w=500"},
    ]
}

# =========================================================
# GENERIC HELPERS
# =========================================================

def now_iso():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def normalize_mongo_doc(doc):
    if not doc:
        return None
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc

def resolve_product_from_catalog(product_id=None, sku=None, title=None):
    if not oracle_available:
        return None

    connection = None
    cursor = None

    try:
        connection = get_oracle_connection()
        cursor = connection.cursor()

        if sku:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(sku) = upper(:sku)
                FETCH FIRST 1 ROWS ONLY
            """, {"sku": sku})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        if product_id:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(sku) = upper(:product_id)
                FETCH FIRST 1 ROWS ONLY
            """, {"product_id": product_id})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        if title:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(product_name) = upper(:title)
                FETCH FIRST 1 ROWS ONLY
            """, {"title": title})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        return None

    except Exception as e:
        print(f"Catalog lookup error: {e}")
        return None

    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def api_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        customer_id = session.get("customer_id")
        if not customer_id:
            customer_id = request.cookies.get("customer_id")

        if not customer_id:
            return jsonify({
                "success": False,
                "error": "Authentication required",
                "message": "customer_id missing from session and cookie"
            }), 401

        session["customer_id"] = customer_id
        return f(*args, **kwargs)
    return decorated_function


# =========================================================
# USER / PROFILE HELPERS
# =========================================================

def get_document_user(email):
    if not document_users_enabled():
        return None
    user = app_users_collection.find_one({"email": email})
    return normalize_mongo_doc(user)


def get_document_profile_by_customer_id(customer_id):
    if not document_store_enabled():
        return None
    try:
        customer_id = int(customer_id)
    except Exception:
        return None
    profile = customers_collection.find_one({"customerId": customer_id})
    return normalize_mongo_doc(profile)


# =========================================================
# CART HELPERS
# =========================================================

def empty_cart_document(customer_id):
    return {
        "cart_id": f"cart_{uuid.uuid4().hex[:8]}",
        "customer_id": str(customer_id),
        "session_id": session.get("session_id", f"sess_{uuid.uuid4().hex[:8]}"),
        "status": "active",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "expires_at": (datetime.utcnow() + timedelta(days=30)).replace(microsecond=0).isoformat() + "Z",
        "pricing": {
            "subtotal": 0,
            "discount_total": 0,
            "tax_rate": 0.08,
            "tax": 0,
            "shipping": 0,
            "total": 0,
            "currency": "USD",
        },
        "applied_coupons": [],
        "shipping_address": {},
        "saved_for_later": [],
        "cart_items": [],
    }


def calculate_cart_pricing(cart_items):
    if not cart_items:
        return {
            "subtotal": 0,
            "discount_total": 0,
            "tax_rate": 0.08,
            "tax": 0,
            "shipping": 0,
            "total": 0,
            "currency": "USD",
        }

    subtotal = sum(float(item["total"]) for item in cart_items)
    discount_total = sum(
        (float(item["price"]) - float(item["discounted_price"])) * int(item["quantity"])
        for item in cart_items
    )
    tax_rate = 0.08
    tax = round(subtotal * tax_rate, 2)
    shipping = 9.99 if subtotal < 75 else 0
    total = round(subtotal + tax + shipping, 2)

    return {
        "subtotal": round(subtotal, 2),
        "discount_total": round(discount_total, 2),
        "tax_rate": tax_rate,
        "tax": tax,
        "shipping": shipping,
        "total": total,
        "currency": "USD",
    }


def get_customer_cart(customer_id):
    if not document_cart_enabled():
        return None

    cart = shopping_cart_collection.find_one({
        "customer_id": str(customer_id),
        "status": "active"
    })

    if not cart:
        new_cart = empty_cart_document(customer_id)
        shopping_cart_collection.insert_one(new_cart)
        cart = shopping_cart_collection.find_one({
            "customer_id": str(customer_id),
            "status": "active"
        })

    return normalize_mongo_doc(cart)


def save_customer_cart(cart):
    payload = dict(cart)
    payload.pop("_id", None)
    payload["updated_at"] = now_iso()

    shopping_cart_collection.update_one(
        {
            "cart_id": payload["cart_id"],
            "customer_id": payload["customer_id"]
        },
        {"$set": payload},
        upsert=True
    )


def update_cart_item_quantity(customer_id, product_id, new_quantity):
    cart = get_customer_cart(customer_id)
    if not cart:
        return False

    found = False
    for item in cart["cart_items"]:
        if str(item["product_id"]) == str(product_id):
            item["quantity"] = int(new_quantity)
            item["total"] = round(float(item["discounted_price"]) * int(new_quantity), 2)
            found = True
            break

    if not found:
        return False

    cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
    save_customer_cart(cart)
    return True


def remove_cart_item_from_document_store(customer_id, product_id):
    cart = get_customer_cart(customer_id)
    if not cart:
        return False

    initial_len = len(cart["cart_items"])
    cart["cart_items"] = [
        item for item in cart["cart_items"]
        if str(item["product_id"]) != str(product_id)
    ]

    if len(cart["cart_items"]) == initial_len:
        return False

    cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
    save_customer_cart(cart)
    return True


# =========================================================
# CHAT HELPERS
# =========================================================

def get_chat_history(customer_id):
    if not document_chat_enabled():
        return []

    docs = list(
        chat_history_collection.find(
            {"customer_id": str(customer_id)},
            {"_id": 0}
        ).sort("chat_timestamp", 1)
    )
    return docs


def save_chat_message(customer_id, user_message, assistant_response):
    if not document_chat_enabled():
        return

    chat_history_collection.insert_one({
        "customer_id": str(customer_id),
        "session_id": str(request.cookies.get("session", session.get("_id", "default-session"))),
        "message": str(user_message),
        "response": str(assistant_response),
        "chat_timestamp": now_iso()
    })


# =========================================================
# ORACLE AI TEAM (OPTIONAL)
# =========================================================

def run_ai_agent_team(prompt, conversation_id):
    if not oracle_available:
        conv_id = conversation_id or f"local-{uuid.uuid4().hex[:8]}"
        session["select_ai_conversation_id"] = conv_id
        return conv_id, "I’m connected to your profile and cart, but Oracle AI is not configured right now."

    connection = None
    cursor = None

    try:
        connection = get_oracle_connection()
        cursor = connection.cursor()
        cursor.callproc("dbms_output.enable")

        if conversation_id == "":
            conversation_id_var = cursor.var(str)
            cursor.execute(
                """
                BEGIN
                    :conv_id := DBMS_CLOUD_AI.CREATE_CONVERSATION();
                END;
                """,
                {"conv_id": conversation_id_var}
            )
            conv_id = conversation_id_var.getvalue()
            session["select_ai_conversation_id"] = conv_id
        else:
            conv_id = conversation_id

        response_var = cursor.var(str)
        params_json = '{"conversation_id": "' + conv_id + '"}'

        cursor.execute(
            """
            BEGIN
                :response := DBMS_CLOUD_AI_AGENT.RUN_TEAM(
                    team_name   => 'fashion_advisor_team',
                    user_prompt => :prompt,
                    params      => :params
                );
            END;
            """,
            {"response": response_var, "prompt": prompt, "params": params_json}
        )

        ai_response = response_var.getvalue()
        connection.commit()
        return conv_id, ai_response

    except oracledb.DatabaseError as e:
        error, = e.args
        print(f"Database error code: {getattr(error, 'code', 'N/A')}")
        print(f"Database error message: {getattr(error, 'message', str(e))}")
        raise

    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


# =========================================================
# ROUTES
# =========================================================

@app.route("/")
def index():
    return redirect(url_for("home"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip()
        password = (request.form.get("password") or "").strip()

        if not email or not password:
            return render_template("login.html", error="Please enter both email and password.")

        # Document backend first
        if document_users_enabled():
            user = get_document_user(email)
            if user and user.get("password") == password and str(user.get("is_active", "Y")).upper() == "Y":
                session["user_email"] = user.get("email")
                session["user_name"] = user.get("full_name", "User")
                session["customer_id"] = user.get("customer_id")
                session["logged_in"] = True
                session["select_ai_conversation_id"] = ""
                session["auth_source"] = "document_store"
                return redirect(url_for("home"))

        # Oracle fallback only for disabled mode
        if Config.DOCUMENT_BACKEND == "disabled" and oracle_available:
            try:
                connection = get_oracle_connection()
                cursor = connection.cursor()
                cursor.execute("""
                    SELECT email, full_name, password, customer_id, is_active
                    FROM app_users
                    WHERE LOWER(email) = LOWER(:email)
                """, {"email": email})
                row = cursor.fetchone()
                cursor.close()
                connection.close()

                if row:
                    db_email, full_name, db_password, customer_id, is_active = row
                    if db_password == password and str(is_active).upper() == "Y":
                        session["user_email"] = db_email
                        session["user_name"] = full_name or db_email
                        session["customer_id"] = customer_id
                        session["logged_in"] = True
                        session["select_ai_conversation_id"] = ""
                        session["auth_source"] = "oracle"
                        return redirect(url_for("home"))
            except Exception as e:
                print(f"Oracle login error: {e}")

        return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/home")
def home():
    user_name = session.get("user_name", "Guest")
    featured = PRODUCTS["men"][:2] + PRODUCTS["women"][:2] + PRODUCTS["kids"][:2]
    return render_template("home.html", user_name=user_name, featured_products=featured)


@app.route("/shop")
@app.route("/shop/<category>")
def shop(category=None):
    user_name = session.get("user_name", "Guest")

    if category and category in PRODUCTS:
        products = PRODUCTS[category]
    else:
        products = []
        for category_products in PRODUCTS.values():
            products.extend(category_products)

    return render_template("shop.html", user_name=user_name, products=products, category=category)


@app.route("/product/<int:product_id>")
def product_detail(product_id):
    user_name = session.get("user_name", "Guest")
    product = None

    for category_products in PRODUCTS.values():
        for p in category_products:
            if p["id"] == product_id:
                product = p
                break
        if product:
            break

    return render_template("product.html", user_name=user_name, product=product)


@app.route("/profile")
@login_required
def profile():
    user_name = session.get("user_name", "Guest")
    customer_id = session.get("customer_id")
    customer = None

    if document_store_enabled():
        customer = get_document_profile_by_customer_id(customer_id)

    if not customer and Config.DOCUMENT_BACKEND == "disabled" and oracle_available:
        try:
            connection = get_oracle_connection()
            cursor = connection.cursor()
            cursor.execute("""
                SELECT profile_json
                FROM customer_profile_oracle
                WHERE customer_id = :customer_id
            """, {"customer_id": customer_id})
            row = cursor.fetchone()
            cursor.close()
            connection.close()

            if row and row[0]:
                raw_json = row[0].read() if hasattr(row[0], "read") else row[0]
                customer = json.loads(raw_json)
        except Exception as e:
            print(f"Oracle profile error: {e}")

    if not customer:
        flash("Profile not found.", "error")
        return redirect(url_for("home"))

    return render_template("profile.html", user_name=user_name, customer=customer)


# =========================================================
# CHAT APIS
# =========================================================

@app.route("/api/chat", methods=["POST"])
@login_required
def chat():
    data = request.get_json() or {}
    user_message = str(data.get("message", "")).strip()

    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    try:
        full_user_message = (
            "Context information: "
            + "Customer Name: " + str(session.get("user_name", ""))
            + " ; Session Cookie: " + str(request.cookies.get("session"))
            + " ; customer_id: " + str(session.get("customer_id"))
            + " . User prompt: " + str(user_message)
        )

        conversation_id = session.get("select_ai_conversation_id", "")
        conversation_id, response_text = run_ai_agent_team(full_user_message, conversation_id)

        if response_text is None:
            response_text = "No response returned from AI agent team."
        response_text = str(response_text).strip() or "AI agent team returned an empty response."

        save_chat_message(session.get("customer_id", 0), user_message, response_text)

        return jsonify({
            "response": response_text,
            "timestamp": now_iso(),
            "conversation_id": conversation_id
        })

    except Exception as e:
        print(f"Chat error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Chat service unavailable", "details": str(e)}), 500


@app.route("/api/chat/clear", methods=["POST"])
@login_required
def clear_chat():
    try:
        customer_id = session.get("customer_id", 0)
        if document_chat_enabled():
            chat_history_collection.delete_many({"customer_id": str(customer_id)})
        session["select_ai_conversation_id"] = ""
        return jsonify({"status": "success", "message": "Chat history cleared"})
    except Exception as e:
        print(f"Clear chat error: {str(e)}")
        return jsonify({"error": "Failed to clear chat history"}), 500


@app.route("/api/chat/history", methods=["GET"])
@login_required
def chat_history():
    customer_id = session.get("customer_id", 0)

    if not customer_id:
        return jsonify({"success": False, "message": "Authentication required"}), 401

    try:
        history = []
        if document_chat_enabled():
            docs = get_chat_history(customer_id)
            for doc in docs:
                history.append({
                    "user_message": str(doc.get("message", "")),
                    "assistant_message": str(doc.get("response", "")),
                    "timestamp": doc.get("chat_timestamp")
                })

        return jsonify({"success": True, "history": history}), 200

    except Exception as e:
        print(f"Chat history error: {str(e)}")
        return jsonify({"success": False, "error": "Failed to load chat history", "details": str(e)}), 500


# =========================================================
# CART ROUTES / APIS
# =========================================================

@app.route("/cart")
@login_required
def cart():
    user_name = session.get("user_name", "Guest")
    customer_id = session.get("customer_id")
    cart_data = get_customer_cart(customer_id) if customer_id else None
    return render_template("cart.html", user_name=user_name, cart=cart_data, customer_id=customer_id)


@app.route("/api/v1/cart", methods=["GET"])
@api_login_required
def api_get_cart():
    customer_id = session.get("customer_id")
    cart = get_customer_cart(customer_id)
    if not cart:
        return jsonify({"success": False, "message": "No active cart found"}), 404
    return jsonify({"success": True, "data": cart}), 200


@app.route("/api/v1/cart", methods=["POST"])
@api_login_required
def api_create_cart():
    try:
        customer_id = session.get("customer_id")
        existing_cart = get_customer_cart(customer_id)
        if existing_cart:
            return jsonify({"success": True, "message": "Active cart already exists", "data": existing_cart}), 200

        if document_cart_enabled():
            new_cart = empty_cart_document(customer_id)
            shopping_cart_collection.insert_one(new_cart)
            created_cart = get_customer_cart(customer_id)
            return jsonify({"success": True, "message": "Cart created successfully", "data": created_cart}), 201

        return jsonify({"success": False, "error": "Document cart is not enabled"}), 500

    except Exception as e:
        print(f"Error creating cart: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/v1/cart/items", methods=["POST"])
@api_login_required
def api_add_cart_item():
    try:
        customer_id = session.get("customer_id")
        data = request.json or {}

        if not document_cart_enabled():
            return jsonify({"success": False, "error": "Document cart is not enabled"}), 500

        # only shopper-facing minimum
        if not data.get("quantity"):
            data["quantity"] = 1

        if not data.get("product_id") and not data.get("sku") and not data.get("title"):
            return jsonify({
                "success": False,
                "error": "MISSING_PRODUCT_IDENTIFIER",
                "message": "Provide at least product_id, sku, or title"
            }), 400

        # resolve missing backend fields from catalog
        catalog_product = resolve_product_from_catalog(
            product_id=data.get("product_id"),
            sku=data.get("sku"),
            title=data.get("title")
        )

        if catalog_product:
            data["product_id"] = data.get("product_id") or catalog_product["product_id"]
            data["sku"] = data.get("sku") or catalog_product["sku"]
            data["title"] = data.get("title") or catalog_product["title"]
            data["category"] = data.get("category") or catalog_product["category"]
            data["brand"] = data.get("brand") or catalog_product["brand"]
            data["price"] = data.get("price", catalog_product["price"])
            data["discount_percentage"] = data.get("discount_percentage", catalog_product["discount_percentage"])
            data["image_url"] = data.get("image_url") or catalog_product["image_url"]
            if "in_stock" not in data or data.get("in_stock") in (None, "", []):
                data["in_stock"] = catalog_product["in_stock"]

        required_fields = ["product_id", "title", "price", "quantity"]
        missing_fields = [field for field in required_fields if field not in data or data.get(field) in (None, "", [])]
        if missing_fields:
            return jsonify({
                "success": False,
                "error": "MISSING_REQUIRED_FIELDS",
                "message": "Missing required fields for add to cart",
                "missing_fields": missing_fields
            }), 400

        cart = get_customer_cart(customer_id)

        discount_percentage = float(data.get("discount_percentage", 0) or 0)
        price = float(data["price"])
        discounted_price = round(price * (1 - discount_percentage / 100), 2)
        quantity = int(data.get("quantity", 1) or 1)

        cart_item = {
            "product_id": str(data["product_id"]),
            "sku": data.get("sku", str(data["product_id"])),
            "title": data["title"],
            "category": data.get("category", ""),
            "color": data.get("color", ""),
            "size": data.get("size", ""),
            "brand": data.get("brand", ""),
            "price": price,
            "quantity": quantity,
            "discount_percentage": discount_percentage,
            "discounted_price": discounted_price,
            "total": round(discounted_price * quantity, 2),
            "image_url": data.get("image_url", ""),
            "in_stock": bool(data.get("in_stock", True)),
            "added_at": now_iso()
        }

        item_exists = False
        for item in cart["cart_items"]:
            same_product = str(item.get("product_id")) == str(cart_item["product_id"])
            same_size = str(item.get("size", "")) == str(cart_item["size"])
            same_color = str(item.get("color", "")) == str(cart_item["color"])

            if same_product and same_size and same_color:
                item["quantity"] = int(item["quantity"]) + quantity
                item["total"] = round(float(item["discounted_price"]) * int(item["quantity"]), 2)
                item_exists = True
                break

        if not item_exists:
            cart["cart_items"].append(cart_item)

        cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
        save_customer_cart(cart)

        updated_cart = get_customer_cart(customer_id)
        return jsonify({
            "success": True,
            "message": "Item added to cart successfully",
            "data": updated_cart
        }), 200

    except Exception as e:
        error_message = str(e)
        print(f"Error adding item to cart: {error_message}")
        return jsonify({
            "success": False,
            "error": "ADD_TO_CART_FAILED",
            "message": error_message
        }), 500

@app.route("/api/v1/cart/items/<product_id>", methods=["PATCH"])
@api_login_required
def api_update_cart_item(product_id):
    try:
        customer_id = session.get("customer_id")
        data = request.json or {}

        if "quantity" not in data:
            return jsonify({"success": False, "error": "Quantity is required"}), 400

        quantity = int(data["quantity"])
        if quantity < 1:
            return jsonify({"success": False, "error": "Quantity must be at least 1"}), 400
        if quantity > 10:
            return jsonify({"success": False, "error": "Quantity cannot exceed 10"}), 400

        success = update_cart_item_quantity(customer_id, product_id, quantity)
        if not success:
            return jsonify({"success": False, "message": "Failed to update item quantity"}), 404

        cart = get_customer_cart(customer_id)
        return jsonify({"success": True, "message": "Item quantity updated successfully", "data": cart}), 200

    except Exception as e:
        print(f"Error updating cart item: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/v1/cart/items/<product_id>", methods=["DELETE"])
@api_login_required
def api_remove_cart_item(product_id):
    try:
        customer_id = session.get("customer_id")
        success = remove_cart_item_from_document_store(customer_id, product_id)
        if not success:
            return jsonify({"success": False, "message": "Failed to remove item from cart"}), 404

        cart = get_customer_cart(customer_id)
        return jsonify({"success": True, "message": "Item removed from cart successfully", "data": cart}), 200

    except Exception as e:
        print(f"Error removing cart item: {e}")
        return jsonify({"success": False, "error": str(e)}), 500



# =========================================================
# ADMIN ROUTES
# =========================================================

@app.route("/admin")
def admin_dashboard():
    user_name = session.get("user_name", "Admin")

    if document_store_enabled():
        total_customers = customers_collection.count_documents({})
        pipeline = [{
            "$group": {
                "_id": None,
                "total_revenue": {"$sum": "$purchaseHistory.lifetimeValue"},
                "total_orders": {"$sum": "$purchaseHistory.totalOrders"},
                "avg_order_value": {"$avg": "$purchaseHistory.averageOrderValue"}
            }
        }]
        stats = list(customers_collection.aggregate(pipeline))
    else:
        total_customers = 0
        stats = []

    dashboard_stats = {
        "total_customers": total_customers,
        "total_revenue": stats[0]["total_revenue"] if stats else 0,
        "total_orders": stats[0]["total_orders"] if stats else 0,
        "avg_order_value": stats[0]["avg_order_value"] if stats else 0
    }

    return render_template("admin/dashboard.html", user_name=user_name, stats=dashboard_stats)


@app.route("/admin/customers")
def admin_customers():
    user_name = session.get("user_name", "Admin")
    customers = list(customers_collection.find().limit(100)) if document_store_enabled() else []
    return render_template("admin/customers.html", user_name=user_name, customers=customers)


@app.route("/admin/orders")
def admin_orders():
    user_name = session.get("user_name", "Admin")
    if document_store_enabled():
        customers = list(
            customers_collection.find({"purchaseHistory.totalOrders": {"$gt": 0}})
            .sort("purchaseHistory.lastOrderDate", -1)
            .limit(50)
        )
    else:
        customers = []
    return render_template("admin/orders.html", user_name=user_name, customers=customers)


# =========================================================
# ARTICLES / FAQ
# =========================================================

ARTICLES_DIR = Path("content/articles")
FAQ_FILE = Path(__file__).parent / "content" / "faq.md"


def get_article_metadata(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            metadata = yaml.safe_load(parts[1])
            article_content = parts[2].strip()
            return metadata, article_content
    return {}, content


def load_articles():
    articles = []
    if not ARTICLES_DIR.exists():
        ARTICLES_DIR.mkdir(parents=True, exist_ok=True)
        return []

    md_files = list(ARTICLES_DIR.glob("*.md"))
    for filepath in md_files:
        try:
            metadata, content = get_article_metadata(filepath)
            if not metadata:
                continue

            html_content = markdown.markdown(content, extensions=["extra", "codehilite", "toc"])
            date_value = metadata.get("date", datetime.now())

            try:
                if isinstance(date_value, str):
                    pub_date = datetime.strptime(date_value, "%Y-%m-%d")
                elif isinstance(date_value, datetime):
                    pub_date = date_value
                else:
                    from datetime import date as date_type
                    if isinstance(date_value, date_type):
                        pub_date = datetime.combine(date_value, datetime.min.time())
                    else:
                        pub_date = datetime.now()
            except Exception:
                pub_date = datetime.now()

            tags = metadata.get("tags", "")
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",")]
            elif not isinstance(tags, list):
                tags = []

            articles.append({
                "_id": metadata.get("slug", filepath.stem),
                "title": metadata.get("title", "Untitled"),
                "slug": metadata.get("slug", filepath.stem),
                "category": metadata.get("category", "General"),
                "summary": metadata.get("summary", ""),
                "content": html_content,
                "featuredImage": metadata.get("image", ""),
                "author": metadata.get("author", "Anonymous"),
                "status": "published",
                "tags": tags,
                "publishedDate": pub_date,
                "views": 0,
                "filepath": filepath,
            })
        except Exception as e:
            print(f"Error loading article {filepath}: {e}")

    articles.sort(key=lambda x: x["publishedDate"], reverse=True)
    return articles


def get_article_by_slug(slug):
    for article in load_articles():
        if article["slug"] == slug or article["_id"] == slug:
            return article
    return None


def load_faq():
    if not FAQ_FILE.exists():
        return {
            "title": "FAQ",
            "description": "Frequently Asked Questions",
            "content": "<p>FAQ content not found.</p>",
            "sections": [],
        }

    try:
        with open(FAQ_FILE, "r", encoding="utf-8") as f:
            content = f.read()

        metadata = {}
        faq_content = content

        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                metadata = yaml.safe_load(parts[1])
                faq_content = parts[2].strip()

        html_content = markdown.markdown(faq_content, extensions=["extra", "toc", "codehilite"])

        sections = []
        for line in faq_content.split("\n"):
            if line.startswith("## "):
                section_title = line.replace("## ", "").strip()
                section_id = section_title.lower().replace(" ", "-").replace("&", "and")
                sections.append({"title": section_title, "id": section_id})

        return {
            "title": metadata.get("title", "FAQ"),
            "description": metadata.get("description", ""),
            "content": html_content,
            "sections": sections,
            "last_updated": metadata.get("last_updated", ""),
        }
    except Exception as e:
        print(f"Error loading FAQ: {e}")
        return {
            "title": "FAQ",
            "description": "Frequently Asked Questions",
            "content": "<p>Error loading FAQ content.</p>",
            "sections": [],
        }


@app.route("/articles")
def articles_list():
    user_name = session.get("user_name", "Guest")
    return render_template("articles/list.html", user_name=user_name, articles=load_articles())


@app.route("/articles/<article_id>")
def article_detail(article_id):
    user_name = session.get("user_name", "Guest")
    article = get_article_by_slug(article_id)
    if not article:
        return redirect(url_for("articles_list"))
    return render_template("articles/detail.html", user_name=user_name, article=article)


@app.route("/articles/category/<category>")
def articles_by_category(category):
    user_name = session.get("user_name", "Guest")
    all_articles = load_articles()
    articles = [a for a in all_articles if a["category"] == category]
    return render_template("articles/list.html", user_name=user_name, articles=articles, current_category=category)


@app.route("/faq")
def faq():
    user_name = session.get("user_name", "Guest")
    faq_data = load_faq()
    return render_template("faq.html", user_name=user_name, faq=faq_data)


@app.route("/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "fashion-store-api",
        "oracle_available": oracle_available,
        "document_backend_available": document_store_enabled(),
        "timestamp": now_iso()
    }), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)