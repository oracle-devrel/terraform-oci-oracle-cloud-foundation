from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_session import Session
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
import uuid
import json
import re
import markdown
import yaml
import oracledb

from config import Config
from db_connection import get_mongo_db, get_oracle_connection, oracle_env_configured

app = Flask(__name__)
app.config.from_object("config.Config")

# Session configuration
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_PERMANENT"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=2)
Session(app)

# =========================================================
# DATABASE CONNECTIONS
# =========================================================

mongo_db = get_mongo_db()

USE_DOCUMENT_BACKEND = Config.DOCUMENT_BACKEND in ("oracle_api", "atlas")

customers_collection = mongo_db["customer_profile"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
app_users_collection = mongo_db["app_users"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
shopping_cart_collection = mongo_db["shopping_cart"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None
chat_history_collection = mongo_db["chat_history"] if (mongo_db is not None and USE_DOCUMENT_BACKEND) else None


def document_store_enabled():
    return mongo_db is not None and customers_collection is not None


def document_users_enabled():
    return mongo_db is not None and app_users_collection is not None


def document_cart_enabled():
    return mongo_db is not None and shopping_cart_collection is not None


def document_chat_enabled():
    return mongo_db is not None and chat_history_collection is not None


oracle_available = False
if oracle_env_configured():
    try:
        startup_conn = get_oracle_connection()
        startup_cursor = startup_conn.cursor()
        startup_cursor.execute("select user from dual")
        startup_cursor.fetchone()
        startup_cursor.close()
        startup_conn.close()
        oracle_available = True
    except Exception as e:
        print(f"Startup Oracle test failed: {e}")
        oracle_available = False

if document_store_enabled():
    print("Startup Mongo-compatible test: customer_profile/app_users/shopping_cart/chat_history available")
else:
    print("Startup Mongo-compatible test: document backend disabled or unavailable")

# =========================================================
# DEMO PRODUCTS
# =========================================================

PRODUCTS = {
    "men": [
        {"id": 1, "name": "Classic Denim Jacket", "price": 89.99, "category": "men", "image": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500"},
        {"id": 2, "name": "Cotton Polo Shirt", "price": 45.99, "category": "men", "image": "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=500"},
        {"id": 3, "name": "Slim Fit Chinos", "price": 65.99, "category": "men", "image": "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500"},
        {"id": 4, "name": "Leather Sneakers", "price": 120.00, "category": "men", "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500"},
    ],
    "women": [
        {"id": 5, "name": "Floral Summer Dress", "price": 79.99, "category": "women", "image": "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=500"},
        {"id": 6, "name": "Cashmere Sweater", "price": 95.00, "category": "women", "image": "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500"},
        {"id": 7, "name": "High-Waist Jeans", "price": 72.50, "category": "women", "image": "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500"},
        {"id": 8, "name": "Ankle Boots", "price": 135.00, "category": "women", "image": "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500"},
    ],
    "kids": [
        {"id": 9, "name": "Kids Graphic Tee", "price": 24.99, "category": "kids", "image": "https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?w=500"},
        {"id": 10, "name": "Denim Overalls", "price": 42.00, "category": "kids", "image": "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=500"},
        {"id": 11, "name": "Colorful Sneakers", "price": 55.00, "category": "kids", "image": "https://images.unsplash.com/photo-1514989940723-e8e51635b782?w=500"},
        {"id": 12, "name": "Winter Jacket", "price": 68.00, "category": "kids", "image": "https://images.unsplash.com/photo-1578932750294-f5075e85f44a?w=500"},
    ]
}

# =========================================================
# GENERIC HELPERS
# =========================================================

def now_iso():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def normalize_mongo_doc(doc):
    if not doc:
        return None
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc

def resolve_product_from_catalog(product_id=None, sku=None, title=None):
    if not oracle_available:
        return None

    connection = None
    cursor = None

    try:
        connection = get_oracle_connection()
        cursor = connection.cursor()

        if sku:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(sku) = upper(:sku)
                FETCH FIRST 1 ROWS ONLY
            """, {"sku": sku})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        if product_id:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(sku) = upper(:product_id)
                FETCH FIRST 1 ROWS ONLY
            """, {"product_id": product_id})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        if title:
            cursor.execute("""
                SELECT sku,
                       product_name,
                       category,
                       brand,
                       price_usd,
                       discount_percent,
                       in_stock
                FROM product_catalog
                WHERE upper(product_name) = upper(:title)
                FETCH FIRST 1 ROWS ONLY
            """, {"title": title})
            row = cursor.fetchone()
            if row:
                return {
                    "sku": row[0],
                    "product_id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "brand": row[3],
                    "price": float(row[4]) if row[4] is not None else 0.0,
                    "discount_percentage": float(row[5]) if row[5] is not None else 0.0,
                    "in_stock": str(row[6]).lower() in ("y", "yes", "true", "1"),
                    "image_url": ""
                }

        return None

    except Exception as e:
        print(f"Catalog lookup error: {e}")
        return None

    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            # API callers need a machine-readable auth failure. Returning the
            # normal HTML login redirect here makes fetch() try to parse an
            # HTML page as JSON and the browser reports the misleading
            # "Chat service unavailable" message.
            if request.path.startswith("/api/") or request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify({
                    "error": "AUTHENTICATION_REQUIRED",
                    "message": "Your session has expired. Please log in again.",
                }), 401
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def api_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        customer_id = session.get("customer_id")
        if not customer_id:
            customer_id = request.cookies.get("customer_id")

        if not customer_id:
            return jsonify({
                "success": False,
                "error": "Authentication required",
                "message": "customer_id missing from session and cookie"
            }), 401

        session["customer_id"] = customer_id
        return f(*args, **kwargs)
    return decorated_function


# =========================================================
# USER / PROFILE HELPERS
# =========================================================

def get_document_user(email):
    if not document_users_enabled():
        return None
    user = app_users_collection.find_one({"email": email})
    return normalize_mongo_doc(user)


def get_document_profile_by_customer_id(customer_id):
    if not document_store_enabled():
        return None
    try:
        customer_id = int(customer_id)
    except Exception:
        return None
    profile = customers_collection.find_one({"customerId": customer_id})
    return normalize_mongo_doc(profile)


def get_chat_profile(customer_id):
    """Return the authenticated customer's profile for internal chat context."""
    profile = get_document_profile_by_customer_id(customer_id)
    return profile or {}


def format_chat_profile_context(profile):
    """Flatten the profile into safe, readable context for the AI team."""
    if not profile:
        return "unavailable"

    personal = profile.get("personalInfo") or {}
    account = profile.get("accountInfo") or {}
    purchase = profile.get("purchaseHistory") or {}
    clothing = profile.get("clothingPreferences") or {}
    preferred_sizes = clothing.get("preferredSize") or {}
    colors = clothing.get("favoriteColors") or []
    brands = clothing.get("favoriteBrands") or []
    addresses = profile.get("shippingAddresses") or []
    default_address = next(
        (address for address in addresses if str(address.get("isDefault", "")).lower() == "true"),
        addresses[0] if addresses else {},
    )

    fields = [
        ("Full name", personal.get("fullName")),
        ("Email", personal.get("email")),
        ("Phone number", personal.get("phoneNumber")),
        ("Date of birth", personal.get("dateOfBirth")),
        ("Gender", personal.get("gender")),
        ("Loyalty tier", account.get("loyaltyTier")),
        ("Loyalty points", account.get("loyaltyPoints")),
        ("Total orders", purchase.get("totalOrders")),
        ("Lifetime value", purchase.get("lifetimeValue")),
        ("Preferred style", clothing.get("preferredStyle")),
        ("Top size", preferred_sizes.get("tops")),
        ("Bottom size", preferred_sizes.get("bottoms")),
        ("Shoe size", preferred_sizes.get("shoes")),
        ("Favorite colors", ", ".join(str(value) for value in colors)),
        ("Favorite brands", ", ".join(str(value) for value in brands)),
        ("Default shipping city", default_address.get("city")),
        ("Default shipping country", default_address.get("country")),
    ]
    return "; ".join(f"{label}: {value}" for label, value in fields if value not in (None, ""))


def direct_profile_request(user_message, customer_id):
    """Answer basic profile questions directly from the authenticated profile."""
    normalized = normalize_cart_query(user_message)
    shopping_intent_terms = (
        " what should i buy ", " what do i buy ", " recommend ", " recommendation ",
        " buy ", " purchase ", " shopping ", " catalog ", " catalogue ",
        " product ", " products ", " item ", " items ", " in stock ",
        " add to my cart ", " add them ", " cart ", " winter ", " switzerland ",
        " elveția ", " elvetia ", " switzerland in winter ",
    )
    explicit_profile_question_terms = (
        " what is my ", " what are my ", " what s my ", " what s in my profile ",
        " tell me my ", " show me my ", " do you know my ", " read my profile ",
        " can you see my profile ", " citește-mi profilul ", " citeste mi profilul ",
    )
    if any(term in normalized for term in shopping_intent_terms) and not any(
        term in normalized for term in explicit_profile_question_terms
    ):
        return None

    profile_terms = (
        " phone ", " phone number ", " telefon ", " nr de tel ",
        " numar de telefon ", " număr de telefon ", " email ", " e mail ",
        " full name ", " my name ", " numele meu ", " data nașterii ",
        " data nasterii ", " date of birth ", " birthday ", " gender ",
        " genul meu ", " loyalty ", " loyalty points ", " puncte ",
        " profile ", " profil ", " personal information ", " informații personale ",
        " informatii personale ", " shoe size ", " size ", " mărimea ",
        " marimea ", " favorite colors ", " favorite brands ", " preferințe ",
        " preferinte ", " shipping address ", " adresa mea ", " my orders ",
        " comenzile mele ",
    )
    if not any(term in normalized for term in profile_terms):
        return None

    profile = get_chat_profile(customer_id)
    if not profile:
        return "I could not load your profile right now."

    personal = profile.get("personalInfo") or {}
    account = profile.get("accountInfo") or {}
    purchase = profile.get("purchaseHistory") or {}
    clothing = profile.get("clothingPreferences") or {}
    preferred_sizes = clothing.get("preferredSize") or {}
    romanian = detect_response_language(user_message) == "Romanian"

    if any(term in normalized for term in (" phone ", " phone number ", " telefon ", " nr de tel ", " numar de telefon ", " număr de telefon ")):
        value = personal.get("phoneNumber", "not available")
        return f"Numărul tău de telefon este {value}." if romanian else f"Your phone number is {value}."
    if any(term in normalized for term in (" email ", " e mail ")):
        value = personal.get("email", "not available")
        return f"Adresa ta de email este {value}." if romanian else f"Your email address is {value}."
    if any(term in normalized for term in (" full name ", " my name ", " numele meu ")):
        value = personal.get("fullName", "not available")
        return f"Numele tău este {value}." if romanian else f"Your name is {value}."
    if any(term in normalized for term in (" date of birth ", " birthday ", " data nașterii ", " data nasterii ")):
        value = personal.get("dateOfBirth", "not available")
        return f"Data ta de naștere este {value}." if romanian else f"Your date of birth is {value}."
    if any(term in normalized for term in (" gender ", " genul meu ")):
        value = personal.get("gender", "not available")
        return f"Genul tău este {value}." if romanian else f"Your gender is {value}."
    if any(term in normalized for term in (" loyalty points ", " loyalty ", " puncte ")):
        tier = account.get("loyaltyTier", "not available")
        points = account.get("loyaltyPoints", "not available")
        return (
            f"Ai nivelul {tier} și {points} puncte de loialitate."
            if romanian else
            f"Your loyalty tier is {tier} with {points} points."
        )
    if any(term in normalized for term in (" shoe size ", " mărimea ", " marimea ")):
        value = preferred_sizes.get("shoes", "not available")
        return f"Mărimea ta la pantofi este {value}." if romanian else f"Your shoe size is {value}."
    if any(term in normalized for term in (" size ",)):
        values = (
            f"top {preferred_sizes.get('tops', 'not available')}, "
            f"bottom {preferred_sizes.get('bottoms', 'not available')}, "
            f"shoes {preferred_sizes.get('shoes', 'not available')}"
        )
        return f"Mărimile tale sunt: {values}." if romanian else f"Your sizes are: {values}."

    summary = format_chat_profile_context(profile)
    return (
        "Profilul tău: " + summary
        if romanian else
        "Your profile: " + summary
    )


# =========================================================
# CART HELPERS
# =========================================================

def empty_cart_document(customer_id):
    return {
        "cart_id": f"cart_{uuid.uuid4().hex[:8]}",
        "customer_id": str(customer_id),
        "session_id": session.get("session_id", f"sess_{uuid.uuid4().hex[:8]}"),
        "status": "active",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "expires_at": (datetime.utcnow() + timedelta(days=30)).replace(microsecond=0).isoformat() + "Z",
        "pricing": {
            "subtotal": 0,
            "discount_total": 0,
            "tax_rate": 0.08,
            "tax": 0,
            "shipping": 0,
            "total": 0,
            "currency": "USD",
        },
        "applied_coupons": [],
        "shipping_address": {},
        "saved_for_later": [],
        "cart_items": [],
    }


def calculate_cart_pricing(cart_items):
    if not cart_items:
        return {
            "subtotal": 0,
            "discount_total": 0,
            "tax_rate": 0.08,
            "tax": 0,
            "shipping": 0,
            "total": 0,
            "currency": "USD",
        }

    subtotal = sum(float(item["total"]) for item in cart_items)
    discount_total = sum(
        (float(item["price"]) - float(item["discounted_price"])) * int(item["quantity"])
        for item in cart_items
    )
    tax_rate = 0.08
    tax = round(subtotal * tax_rate, 2)
    shipping = 9.99 if subtotal < 75 else 0
    total = round(subtotal + tax + shipping, 2)

    return {
        "subtotal": round(subtotal, 2),
        "discount_total": round(discount_total, 2),
        "tax_rate": tax_rate,
        "tax": tax,
        "shipping": shipping,
        "total": total,
        "currency": "USD",
    }


def get_customer_cart(customer_id):
    if not document_cart_enabled():
        return None

    cart = shopping_cart_collection.find_one({
        "customer_id": str(customer_id),
        "status": "active"
    })

    if not cart:
        new_cart = empty_cart_document(customer_id)
        shopping_cart_collection.insert_one(new_cart)
        cart = shopping_cart_collection.find_one({
            "customer_id": str(customer_id),
            "status": "active"
        })

    return normalize_mongo_doc(cart)


def save_customer_cart(cart):
    payload = dict(cart)
    payload.pop("_id", None)
    payload["updated_at"] = now_iso()

    shopping_cart_collection.update_one(
        {
            "cart_id": payload["cart_id"],
            "customer_id": payload["customer_id"]
        },
        {"$set": payload},
        upsert=True
    )


def add_catalog_product_to_cart(customer_id, product, size="", color="", quantity=1):
    """Add a resolved catalog product without asking the LLM to repeat the flow."""
    cart = get_customer_cart(customer_id)
    if not cart or not bool(product.get("in_stock", True)):
        return None

    price = float(product.get("price", 0) or 0)
    discount_percentage = float(product.get("discount_percentage", 0) or 0)
    discounted_price = round(price * (1 - discount_percentage / 100), 2)
    quantity = max(1, min(int(quantity or 1), 10))
    cart_item = {
        "product_id": str(product["product_id"]),
        "sku": product.get("sku", str(product["product_id"])),
        "title": product.get("title", product.get("product_id", "Product")),
        "category": product.get("category", ""),
        "color": color or "",
        "size": size or "",
        "brand": product.get("brand", ""),
        "price": price,
        "quantity": quantity,
        "discount_percentage": discount_percentage,
        "discounted_price": discounted_price,
        "total": round(discounted_price * quantity, 2),
        "image_url": product.get("image_url", ""),
        "in_stock": bool(product.get("in_stock", True)),
        "added_at": now_iso(),
    }

    for item in cart["cart_items"]:
        same_product = str(item.get("product_id")) == str(cart_item["product_id"])
        same_size = str(item.get("size", "")) == str(cart_item["size"])
        same_color = str(item.get("color", "")) == str(cart_item["color"])
        if same_product and same_size and same_color:
            item["quantity"] = min(10, int(item.get("quantity", 0)) + quantity)
            item["total"] = round(float(item["discounted_price"]) * int(item["quantity"]), 2)
            break
    else:
        cart["cart_items"].append(cart_item)

    cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
    save_customer_cart(cart)
    return cart


def extract_product_skus(text):
    return list(dict.fromkeys(re.findall(r"\b[A-Z]{2,4}-\d{4}\b", (text or "").upper())))


def extract_recommendation_details(text):
    """Remember size, color, and quantity stated beside each recommended SKU."""
    details = {}
    for line in str(text or "").splitlines():
        line_skus = extract_product_skus(line)
        if len(line_skus) != 1:
            continue

        sku = line_skus[0]
        normalized = normalize_cart_query(line)
        size_match = re.search(r"\b(?:size|mărimea|marimea)\s*[:=]?\s*(one size|[a-z0-9-]+)", normalized, re.IGNORECASE)
        color_match = re.search(r"\bcolou?r\s*[:=]?\s*([a-z]+)", normalized, re.IGNORECASE)
        quantity_match = re.search(r"\bquantity\s*[:=]?\s*(\d+)", normalized, re.IGNORECASE)

        item_details = {}
        if size_match:
            item_details["size"] = size_match.group(1).upper()
        if color_match:
            item_details["color"] = color_match.group(1).lower()
        if quantity_match:
            item_details["quantity"] = max(1, min(int(quantity_match.group(1)), 10))
        if item_details:
            details[sku] = item_details
    return details


def direct_cart_request(user_message, customer_id):
    """Handle explicit cart references deterministically and quickly."""
    if not document_cart_enabled():
        return None

    normalized = normalize_cart_query(user_message)
    confirmation_reference = normalized.strip() in {
        "da", "yes", "sure", "sigur", "ok", "okay", "perfect",
        "do it", "go ahead", "add them",
    }
    explicit_add_request = any(term in normalized for term in (
        " please add ", " can you add ", " want to add ",
        " add sku ", " add product ", " add item ",
        " add this ", " add that ", " add them ", " add those ", " add it ",
        " put it in my cart ", " put them in my cart ",
        " pune în coș ", " pune in cos ", " pune-le în coș ", " pune le in cos ",
        " adaugă ", " adauga ", " adaugă în coș ", " adauga in cos ",
    )) or bool(re.search(r"\badd\s+[a-z]{2,4}-\d{4}\b", normalized))
    # Recommendations are remembered in the session.  Recognize natural
    # confirmations such as "add all 3 of them to your cart" so they use
    # those remembered SKUs instead of falling through to the LLM.  The LLM
    # sees an empty cart before the add and can incorrectly refuse the request.
    bulk_recommendation_request = bool(re.search(
        r"\b(?:add|put|place)\s+"
        r"(?:(?:all(?:\s+(?:\d+|one|two|three|four|five))?(?:\s+of)?\s+"
        r"(?:them|those|these))|"
        r"(?:all(?:\s+(?:\d+|one|two|three|four|five))?\s+"
        r"(?:recommended|suggested)(?:\s+items?)?)|"
        r"everything|them|those|these)\b",
        normalized,
        re.IGNORECASE,
    ))
    cart_reference = (
        explicit_add_request
        or confirmation_reference
        or bulk_recommendation_request
    )
    skus = extract_product_skus(user_message)
    remembered_details = session.get("last_recommended_details", {}) or {}
    if not skus and cart_reference:
        remembered = session.get("last_recommended_skus", [])
        if 0 < len(remembered) <= 3:
            skus = remembered
    if not skus:
        return None

    quantity = 1
    quantity_match = re.search(r"(?:quantity|cantitate|qty|x)\s*[:=]?\s*(\d+)", normalized)
    quantity_specified = bool(quantity_match)
    if quantity_match:
        quantity = int(quantity_match.group(1))
    elif any(term in normalized for term in (" două ", " doua ", " two ")):
        quantity = 2

    color = ""
    color_map = {
        "black": "black", "negru": "black", "neagră": "black", "neagra": "black",
        "navy": "navy", "bleumarin": "navy", "gray": "gray", "gri": "gray",
        "white": "white", "alb": "white", "alba": "white",
    }
    for label, value in color_map.items():
        if label in normalized:
            color = value
            break

    size = ""
    size_match = re.search(r"(?:size|mărimea|marimea)\s*[:=]?\s*([a-z0-9]+)", normalized)
    if size_match:
        size = size_match.group(1).upper()

    added = []
    unavailable = []
    for sku in skus:
        product = resolve_product_from_catalog(sku=sku)
        recommendation = remembered_details.get(sku, {})
        item_size = size or recommendation.get("size", "")
        item_color = color or recommendation.get("color", "")
        item_quantity = quantity if quantity_specified else recommendation.get("quantity", quantity)
        if product:
            if not bool(product.get("in_stock", True)):
                unavailable.append(product)
                continue
            if add_catalog_product_to_cart(
                customer_id,
                product,
                size=item_size,
                color=item_color,
                quantity=item_quantity,
            ):
                added.append(product)

    if not added:
        if not unavailable:
            return None
        if detect_response_language(user_message) == "Romanian":
            return "Nu pot adăuga în coș produsele indisponibile: " + ", ".join(item["title"] for item in unavailable) + "."
        return "I cannot add these products because they are out of stock: " + ", ".join(item["title"] for item in unavailable) + "."

    if detect_response_language(user_message) == "Romanian":
        response = "Am adăugat în coș: " + ", ".join(item["title"] for item in added) + "."
        if unavailable:
            response += " Nu am adăugat produsele indisponibile: " + ", ".join(item["title"] for item in unavailable) + "."
    else:
        response = "Added to your cart: " + ", ".join(item["title"] for item in added) + "."
        if unavailable:
            response += " I did not add the out-of-stock products: " + ", ".join(item["title"] for item in unavailable) + "."
    session["last_recommended_skus"] = []
    session["last_recommended_details"] = {}
    return response


def direct_cart_contents_request(user_message, customer_id):
    """Answer cart-contents questions from the live cart, without an LLM call."""
    normalized = normalize_cart_query(user_message)
    cart_presence_request = any(term in normalized for term in (
        " in my cart ", " in the cart ", " in cart ",
        " în coș ", " in cos ", " în coșul meu ", " in cosul meu ",
    ))
    requested_skus = extract_product_skus(user_message)

    # SKU presence checks are deterministic reads. Do not send them through
    # the shopping-cart agent, which can take 20+ seconds for a simple lookup.
    if cart_presence_request and requested_skus:
        cart = get_customer_cart(customer_id)
        items = (cart or {}).get("cart_items", [])
        present = {
            str(item.get("sku", "")).upper()
            for item in items
            if item.get("sku")
        }
        found = [sku for sku in requested_skus if sku in present]
        missing = [sku for sku in requested_skus if sku not in present]
        romanian = detect_response_language(user_message) == "Romanian"
        if romanian:
            if found and not missing:
                return "Da, SKU-ul " + ", ".join(found) + " este în coșul tău."
            if missing and not found:
                return "Nu, SKU-ul " + ", ".join(missing) + " nu este în coșul tău."
            return (
                "În coș este/sunt " + ", ".join(found)
                + ", dar nu este/sunt " + ", ".join(missing) + "."
            )
        if found and not missing:
            return "Yes, SKU " + ", ".join(found) + " is in your cart."
        if missing and not found:
            return "No, SKU " + ", ".join(missing) + " is not in your cart."
        return (
            "SKU " + ", ".join(found) + " is in your cart, but SKU "
            + ", ".join(missing) + " is not."
        )

    view_terms = (
        " ce am în coș ", " ce am in cos ", " ce este în coș ", " ce este in cos ",
        " verifici ce am ", " verifică ce am ", " cosul meu ", " coșul meu ",
        " what s in my cart ", " what is in my cart ", " cart contents ",
    )
    if not any(term in normalized for term in view_terms):
        return None

    cart = get_customer_cart(customer_id)
    items = (cart or {}).get("cart_items", [])
    if not items:
        return "Coșul tău este gol." if detect_response_language(user_message) == "Romanian" else "Your cart is empty."

    pricing = calculate_cart_pricing(items)
    item_lines = [
        f"- {item.get('title', item.get('sku', 'Product'))} "
        f"({item.get('sku', '')}, x{item.get('quantity', 1)}, "
        + "$"
        + f"{cart_item_unit_price(item):.2f} each)"
        for item in items
    ]
    if detect_response_language(user_message) == "Romanian":
        return (
            "În coș ai:\n" + "\n".join(item_lines)
            + "\nTotal: " + "$" + f"{pricing['total']:.2f}."
        )
    return (
        "Your cart contains:\n" + "\n".join(item_lines)
        + "\nTotal: " + "$" + f"{pricing['total']:.2f}."
    )


def direct_faq_request(user_message):
    """Answer high-frequency FAQ questions from the deployed FAQ source.

    RAG is useful for broad knowledge retrieval, but these policy answers are
    short, stable and already present in content/faq.md. Returning them here
    avoids an unnecessary Oracle agent/tool round trip and prevents the model
    from claiming that the FAQ is empty when retrieval misses the document.
    """
    normalized = normalize_cart_query(user_message)
    romanian = detect_response_language(user_message) == "Romanian"

    shipping_requested = any(term in normalized for term in (
        " shipping ", " delivery ", " shipping options ", " delivery times ",
        " livrare ", " livrările ", " transport ",
    ))
    returns_requested = any(term in normalized for term in (
        " return ", " returns ", " refund ", " exchange ",
        " retur ", " retururi ", " rambursare ", " schimb ",
    ))

    if not shipping_requested and not returns_requested:
        return None

    sections = []
    if returns_requested:
        if romanian:
            sections.append(
                "Politica de retur este de 30 de zile de la livrare. Produsele trebuie să fie nepurtate, nespălate, cu etichetele și ambalajul original. Returul și schimbul sunt gratuite. Rambursarea se procesează în 3–5 zile lucrătoare după primirea returului, apoi pot fi necesare încă 5–7 zile lucrătoare pentru apariția creditului în cont."
            )
        else:
            sections.append(
                "Our return policy is 30 days from delivery. Items must be unworn, unwashed, with the original tags attached and in the original packaging. Returns and exchanges are free. Refunds are processed within 3–5 business days after we receive the return, and the credit may take another 5–7 business days to appear in your account."
            )
    if shipping_requested:
        if romanian:
            sections.append(
                "Opțiunile de livrare sunt: Standard în 3–5 zile lucrătoare (gratuit pentru comenzi de peste 75 USD, altfel 5,99 USD), Express în 1–2 zile lucrătoare pentru 14,99 USD și livrare a doua zi pentru 24,99 USD la comenzile plasate înainte de ora 14:00. Momentan livrăm doar în Statele Unite."
            )
        else:
            sections.append(
                "Shipping options are: Standard in 3–5 business days (free on orders over $75, otherwise $5.99), Express in 1–2 business days for $14.99, and Next Day Delivery for $24.99 on orders placed before 2 PM. We currently ship within the United States only."
            )
    return "\n\n".join(sections)


def update_cart_item_quantity(customer_id, product_id, new_quantity):
    cart = get_customer_cart(customer_id)
    if not cart:
        return False

    found = False
    for item in cart["cart_items"]:
        if str(item["product_id"]) == str(product_id):
            item["quantity"] = int(new_quantity)
            item["total"] = round(float(item["discounted_price"]) * int(new_quantity), 2)
            found = True
            break

    if not found:
        return False

    cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
    save_customer_cart(cart)
    return True


def remove_cart_item_from_document_store(customer_id, product_id):
    cart = get_customer_cart(customer_id)
    if not cart:
        return False

    initial_len = len(cart["cart_items"])
    cart["cart_items"] = [
        item for item in cart["cart_items"]
        if str(item["product_id"]) != str(product_id)
    ]

    if len(cart["cart_items"]) == initial_len:
        return False

    cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
    save_customer_cart(cart)
    return True


def clear_customer_cart(customer_id):
    """Remove every item from the active cart and recalculate its totals."""
    cart = get_customer_cart(customer_id)
    if not cart:
        return None

    cart["cart_items"] = []
    cart["pricing"] = calculate_cart_pricing([])
    save_customer_cart(cart)
    return cart


def normalize_cart_query(text):
    cleaned = re.sub(r"[^0-9a-zăâîșşțţ]+", " ", str(text or "").casefold()).strip()
    return f" {cleaned} "


def cart_items_matching_message(cart, user_message):
    """Resolve cart items by SKU or by a meaningful part of their title."""
    items = (cart or {}).get("cart_items", [])
    if not items:
        return []

    normalized = normalize_cart_query(user_message)
    requested_skus = set(extract_product_skus(user_message))
    matched = []

    for item in items:
        item_sku = str(item.get("sku", "")).upper()
        if item_sku and item_sku in requested_skus:
            matched.append(item)
            continue

        title = normalize_cart_query(item.get("title", ""))
        title_tokens = [
            token for token in title.strip().split()
            if len(token) >= 4 and token not in {"with", "from", "mens", "womens"}
        ]
        if title.strip() and title.strip() in normalized:
            matched.append(item)
            continue
        if any(f" {token} " in normalized for token in title_tokens):
            matched.append(item)

    # Infer the only item only for explicit pronouns/references such as
    # “remove it” or “how much is this item”, never for a bare cart total.
    implicit_item_reference = any(term in normalized for term in (
        " it ", " this ", " item ", " product ", " acesta ", " aceasta ",
        " produsul ", " el ", " ea ",
    ))
    return matched or (items if len(items) == 1 and implicit_item_reference else [])


def cart_item_unit_price(item):
    return float(item.get("discounted_price", item.get("price", 0)) or 0)


def direct_cart_management_request(user_message, customer_id):
    """Handle cart reads and mutations without sending the request to the LLM."""
    if not document_cart_enabled():
        return None

    normalized = normalize_cart_query(user_message)
    cart = get_customer_cart(customer_id)
    items = (cart or {}).get("cart_items", [])
    romanian = detect_response_language(user_message) == "Romanian"

    clear_requested = any(term in normalized for term in (
        " clear cart ", " clear my cart ", " empty cart ", " empty my cart ",
        " delete cart ", " remove cart ", " delete everything ",
        " remove everything ", " golește coșul ", " goleste cosul ",
        " șterge coșul ", " sterge cosul ",
        " șterge tot ", " sterge tot ", " golește tot ", " goleste tot ",
    ))
    if clear_requested:
        if not items:
            return "Coșul tău este deja gol." if romanian else "Your cart is already empty."
        clear_customer_cart(customer_id)
        return "Am golit coșul." if romanian else "Your cart is now empty."

    remove_requested = any(term in normalized for term in (
        " remove ", " delete ", " șterge ", " sterge ", " elimină ",
        " elimina ", " scoate ", " scoate din coș ", " remove from cart ",
    ))
    quantity_requested = any(term in normalized for term in (
        " quantity to ", " set quantity ", " change quantity ",
        " update quantity ", " increase quantity ", " decrease quantity ",
        " qty ", " cantitate la ", " schimbă cantitatea ",
        " schimba cantitatea ", " setează cantitatea ", " seteaza cantitatea ",
    ))
    quantity_match = re.search(
        r"(?:quantity|cantitate|qty)\s*(?:to|la|=|:)?\s*(\d+)|\bx\s*(\d+)\b",
        normalized,
    )
    if quantity_match:
        quantity_requested = True

    selected_items = cart_items_matching_message(cart, user_message)
    if quantity_requested and not selected_items and len(items) == 1:
        selected_items = items
    if remove_requested:
        if not selected_items:
            return (
                "Spune-mi produsul sau SKU-ul pe care vrei să-l șterg din coș."
                if romanian else
                "Tell me which product or SKU you want me to remove from the cart."
            )
        removed_titles = []
        for item in selected_items:
            if remove_cart_item_from_document_store(customer_id, item.get("product_id")):
                removed_titles.append(item.get("title", item.get("sku", "Product")))
        if not removed_titles:
            return "Nu am găsit produsul în coș." if romanian else "I could not find that product in your cart."
        return (
            "Am șters din coș: " + ", ".join(removed_titles) + "."
            if romanian else
            "Removed from your cart: " + ", ".join(removed_titles) + "."
        )

    if quantity_requested:
        if not selected_items:
            return (
                "Spune-mi produsul și cantitatea dorită."
                if romanian else
                "Tell me the product and the quantity you want."
            )
        new_quantity = int((quantity_match.group(1) or quantity_match.group(2)) if quantity_match else 1)
        if new_quantity < 1 or new_quantity > 10:
            return (
                "Cantitatea trebuie să fie între 1 și 10."
                if romanian else
                "Quantity must be between 1 and 10."
            )
        updated_titles = []
        for item in selected_items:
            if update_cart_item_quantity(customer_id, item.get("product_id"), new_quantity):
                updated_titles.append(item.get("title", item.get("sku", "Product")))
        if not updated_titles:
            return "Nu am putut actualiza coșul." if romanian else "I could not update your cart."
        return (
            f"Am setat cantitatea la {new_quantity} pentru: " + ", ".join(updated_titles) + "."
            if romanian else
            f"Set quantity to {new_quantity} for: " + ", ".join(updated_titles) + "."
        )

    price_requested = any(term in normalized for term in (
        " cât costă ", " cat costa ", " cât mă costă ", " cat ma costa ",
        " cât este ", " cat este ",
        " how much ", " price ", " prices ", " preț ", " pret ",
        " cost ", " total ", " totalul ", " subtotal ", " taxe ", " cu taxe ",
    ))
    cart_context_requested = any(term in normalized for term in (
        " what is the total ", " what s the total ", " whats the total ",
        " what is my total ", " what s my total ", " cart total ",
        " total of my cart ", " total for my cart ", " how much is my cart ",
        " total ", " subtotal ", " tax ", " taxes ", " shipping ",
        " including tax ", " with tax ", " ce total ", " totalul ",
        " taxe ", " cu taxe ",
    ))
    if price_requested and (selected_items or cart_context_requested or len(normalized.strip().split()) <= 3):
        if selected_items:
            lines = []
            for item in selected_items:
                unit_price = cart_item_unit_price(item)
                quantity = int(item.get("quantity", 1) or 1)
                line_total = float(item.get("total", unit_price * quantity) or 0)
                lines.append(
                    f"{item.get('title', item.get('sku', 'Product'))}: "
                    + "$"
                    + f"{unit_price:.2f} each, {quantity} × = $"
                    + f"{line_total:.2f}"
                )
            return (
                ("Prețurile din coș sunt:\n" if romanian else "Cart item prices:\n")
                + "\n".join(lines)
            )

        pricing = calculate_cart_pricing(items)
        if romanian:
            return (
                "Totalul final al coșului, cu taxe, este " + "$" + f"{pricing['total']:.2f}. "
                + "Subtotal: " + "$" + f"{pricing['subtotal']:.2f}, taxă: "
                + "$" + f"{pricing['tax']:.2f}, livrare: "
                + "$" + f"{pricing['shipping']:.2f}."
            )
        return (
            "Your cart total is " + "$" + f"{pricing['total']:.2f}. "
            + "Subtotal: " + "$" + f"{pricing['subtotal']:.2f}, tax: "
            + "$" + f"{pricing['tax']:.2f}, shipping: "
            + "$" + f"{pricing['shipping']:.2f}."
        )

    return None


# =========================================================
# CHAT HELPERS
# =========================================================

def get_chat_history(customer_id):
    if not document_chat_enabled():
        return []

    docs = list(
        chat_history_collection.find(
            {"customer_id": str(customer_id)},
            {"_id": 0}
        ).sort("chat_timestamp", 1)
    )
    return docs


def save_chat_message(customer_id, user_message, assistant_response):
    if not document_chat_enabled():
        return

    chat_history_collection.insert_one({
        "customer_id": str(customer_id),
        "session_id": str(request.cookies.get("session", session.get("_id", "default-session"))),
        "message": str(user_message),
        "response": str(assistant_response),
        "chat_timestamp": now_iso()
    })


# =========================================================
# ORACLE AI TEAM (OPTIONAL)
# =========================================================

def detect_response_language(user_message):
    """Use English by default and switch only when another language is clear."""
    text = str(user_message or "").strip()
    normalized = f" {re.sub(r'[^0-9a-zăâîșşțţ]+', ' ', text.casefold()).strip()} "
    romanian_markers = (
        "ă", "â", "î", "ș", "ş", "ț", "ţ", " să ", " îmi ",
        " imi ", " vreau ", " cumpăr ", " cumpar ", " salut ", " ce faci ",
        " cum ", " unde ", " pentru ",
        " care ", " mă ", " ma ", " poți ", " poti ", " cât costă ",
        " cat costa ", " cât mă costă ", " cat ma costa ", " cât este ",
        " cat este ", " preț ", " pret ", " cu taxe ", " taxe ",
        " totalul ", " telefon ", " nr de tel ", " numar de telefon ",
        " număr de telefon ", " ce nr ", " da ", " sigur ", " pune ",
        " pune-le ", " în cos ", " in cos ", " în coș ", " in coș ",
        " coșul ", " cosul ", " și ", " si ", " adaugă ", " adauga ",
    )
    if any(marker in normalized for marker in romanian_markers):
        return "Romanian"

    # Keep the prompt flexible for clearly non-English requests that are not
    # Romanian. The LLM can then answer in the language used by the customer.
    other_language_markers = (
        " hola ", " buenos días ", " buenos dias ", " gracias ", " por favor ",
        " bonjour ", " merci ", " s'il vous plaît ", " danke ", " bitte ",
        " ciao ", " grazie ", " hallo ", " пожалуйста ", " спасибо ",
        " привет ", " مرحبا ", " شكرا ", " こんにちは ", " ありがとう ",
    )
    if any(marker in normalized for marker in other_language_markers):
        return "the same language as the user"

    # Cyrillic, Arabic, CJK, and non-Roman Latin accents are strong signals
    # that the user intentionally switched away from the English default.
    if re.search(r"[\u0400-\u04ff\u0600-\u06ff\u3040-\u30ff\u3400-\u9fff]", text):
        return "the same language as the user"
    if re.search(r"[ñáéíóúü¿¡çœ]", text.casefold()):
        return "the same language as the user"

    return "English"


def select_agent_team(prompt):
    """Choose the smallest agent team that can answer the current request."""
    # Route from the customer's actual question, not from the appended
    # profile/cart context (which contains words such as “cart”, “phone” and
    # “size” for every conversation).
    user_prompt = str(prompt or "").split(" . User prompt:", 1)[-1]
    normalized = user_prompt.casefold()

    # Match actual cart operations/questions, not incidental wording such as
    # "ask me before adding them to my cart" in a recommendation request.
    cart_terms = (
        "add to cart", "add to my cart", "add them to cart", "add those to cart",
        "please add", "can you add", "want to add", "add sku", "add product", "add item",
        "put it in my cart", "put them in my cart", "shopping cart",
        "what is in my cart", "what s in my cart", "cart contents", "cart total",
        "total of my cart", "how much is my cart", "is in my cart",
        "remove from cart", "delete from cart", "clear cart", "empty cart",
        "remove from my cart", "delete from my cart", "clear my cart", "empty my cart",
        "ce am în coș", "ce am in cos", "coșul meu", "cosul meu", "totalul coșului",
        "totalul cosului", "în coș", "in cos", "șterge din coș", "sterge din cos",
        "golește coșul", "goleste cosul", "pune în coș", "pune in cos",
    )
    weather_terms = (
        "weather", "vreme", "forecast", "prognoza", "october", "octombrie",
        "november", "noiembrie", "december", "decembrie", "season", "sezon",
    )
    faq_terms = (
        "shipping", "delivery", "livrare", "return", "retur", "payment",
        "plată", "plata", "terms", "faq", "order", "comandă", "comanda",
        "promotion", "promoție", "promotie", "discount", "customer service",
    )
    customer_terms = (
        "loyalty", "fidelitate", "profile", "profil", "account", "cont",
        "my orders", "comenzile mele", "my points", "punctele mele",
        "phone", "phone number", "telefon", "nr de tel", "numar de telefon",
        "număr de telefon", "email", "e-mail", "my name", "numele meu",
        "date of birth", "birthday", "data nasterii", "data nașterii",
        "gender", "genul meu", "personal information", "informatii personale",
        "informații personale", "shoe size", "size", "mărimea", "marimea",
        "favorite colors", "favorite brands", "preferinte", "preferințe",
        "shipping address", "adresa mea",
    )
    fashion_terms = (
        "what should i buy", "what do i buy", "what to buy", "recommend",
        "recommendation", "catalog", "catalogue", "products", "product",
        "items", "item", "fashion advice", "fashion recommendation",
        "ce să cumpăr", "ce sa cumpar", "recomandă", "recomanda", "catalog",
        "produse", "produs", "articole",
    )

    if any(term in normalized for term in cart_terms):
        return "shopping_cart_fast_team"
    if any(term in normalized for term in faq_terms):
        return "faq_fast_team"
    # A catalog recommendation that mentions a month/location is still a
    # fashion request; weather is only a separate route when the user asks
    # about weather itself.
    if any(term in normalized for term in fashion_terms):
        return "fashion_fast_team"
    if any(term in normalized for term in weather_terms):
        return "weather_fast_team"
    if any(term in normalized for term in customer_terms):
        return "customer_fast_team"
    return "fashion_fast_team"


def run_ai_agent_team(prompt, conversation_id):
    if not oracle_available:
        conv_id = conversation_id or f"local-{uuid.uuid4().hex[:8]}"
        session["select_ai_conversation_id"] = conv_id
        return conv_id, "I’m connected to your profile and cart, but Oracle AI is not configured right now."

    connection = None
    cursor = None

    try:
        connection = get_oracle_connection()
        cursor = connection.cursor()
        cursor.callproc("dbms_output.enable")

        if conversation_id == "":
            conversation_id_var = cursor.var(str)
            cursor.execute(
                """
                BEGIN
                    :conv_id := DBMS_CLOUD_AI.CREATE_CONVERSATION();
                END;
                """,
                {"conv_id": conversation_id_var}
            )
            conv_id = conversation_id_var.getvalue()
            session["select_ai_conversation_id"] = conv_id
        else:
            conv_id = conversation_id

        # RUN_TEAM returns a CLOB. Bind it as a CLOB and normalize the value
        # before passing it to Flask, otherwise the response can be empty or
        # remain an Oracle LOB object instead of browser-readable text.
        response_var = cursor.var(oracledb.DB_TYPE_CLOB)
        params_json = '{"conversation_id": "' + conv_id + '"}'

        team_name = select_agent_team(prompt)
        print(f"Running AI team {team_name}")
        cursor.execute(
            """
            BEGIN
                :response := DBMS_CLOUD_AI_AGENT.RUN_TEAM(
                    team_name   => :team_name,
                    user_prompt => :prompt,
                    params      => :params
                );
            END;
            """,
            {
                "response": response_var,
                "team_name": team_name,
                "prompt": prompt,
                "params": params_json,
            }
        )

        ai_response = response_var.getvalue()
        if ai_response is not None and hasattr(ai_response, "read"):
            ai_response = ai_response.read()
        elif ai_response is not None:
            ai_response = str(ai_response)
        if not ai_response:
            print("AI agent team returned an empty CLOB response")
        connection.commit()
        return conv_id, ai_response

    except oracledb.DatabaseError as e:
        error, = e.args
        error_message = str(getattr(error, "message", e))

        # Keep older deployments usable while the fast-routing teams are
        # being provisioned. The application can be updated before the
        # database SQL has finished creating the new teams, so a missing fast
        # team must not turn into the generic "Chat service unavailable"
        # message. The original team contains all specialist agents and is a
        # safe, slower fallback.
        fallback_team = (
            "fashion_advisor_team"
            if team_name.endswith("_fast_team")
            and "ORA-20053" in error_message
            and "DOES NOT EXIST" in error_message.upper()
            else None
        )
        if fallback_team:
            print(
                f"AI team {team_name} is not provisioned yet; "
                f"retrying with {fallback_team}"
            )
            fallback_response_var = cursor.var(oracledb.DB_TYPE_CLOB)
            cursor.execute(
                """
                BEGIN
                    :response := DBMS_CLOUD_AI_AGENT.RUN_TEAM(
                        team_name   => :team_name,
                        user_prompt => :prompt,
                        params      => :params
                    );
                END;
                """,
                {
                    "response": fallback_response_var,
                    "team_name": fallback_team,
                    "prompt": prompt,
                    "params": params_json,
                }
            )
            fallback_response = fallback_response_var.getvalue()
            if fallback_response is not None and hasattr(fallback_response, "read"):
                fallback_response = fallback_response.read()
            elif fallback_response is not None:
                fallback_response = str(fallback_response)
            connection.commit()
            return conv_id, fallback_response

        print(f"Database error code: {getattr(error, 'code', 'N/A')}")
        print(f"Database error message: {error_message}")
        raise

    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


# =========================================================
# ROUTES
# =========================================================

@app.route("/")
def index():
    return redirect(url_for("home"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip()
        password = (request.form.get("password") or "").strip()

        if not email or not password:
            return render_template("login.html", error="Please enter both email and password.")

        # Document backend first
        if document_users_enabled():
            user = get_document_user(email)
            if user and user.get("password") == password and str(user.get("is_active", "Y")).upper() == "Y":
                session["user_email"] = user.get("email")
                session["user_name"] = user.get("full_name", "User")
                session["customer_id"] = user.get("customer_id")
                session["logged_in"] = True
                session["select_ai_conversation_id"] = ""
                session["last_recommended_skus"] = []
                session["last_recommended_details"] = {}
                session["auth_source"] = "document_store"
                return redirect(url_for("home"))

        # Oracle fallback only for disabled mode
        if Config.DOCUMENT_BACKEND == "disabled" and oracle_available:
            try:
                connection = get_oracle_connection()
                cursor = connection.cursor()
                cursor.execute("""
                    SELECT email, full_name, password, customer_id, is_active
                    FROM app_users
                    WHERE LOWER(email) = LOWER(:email)
                """, {"email": email})
                row = cursor.fetchone()
                cursor.close()
                connection.close()

                if row:
                    db_email, full_name, db_password, customer_id, is_active = row
                    if db_password == password and str(is_active).upper() == "Y":
                        session["user_email"] = db_email
                        session["user_name"] = full_name or db_email
                        session["customer_id"] = customer_id
                        session["logged_in"] = True
                        session["select_ai_conversation_id"] = ""
                        session["last_recommended_skus"] = []
                        session["last_recommended_details"] = {}
                        session["auth_source"] = "oracle"
                        return redirect(url_for("home"))
            except Exception as e:
                print(f"Oracle login error: {e}")

        return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")


@app.route("/logout")
def logout():
    customer_id = session.get("customer_id")
    if customer_id and document_chat_enabled():
        try:
            # A logout starts a fresh chat on the next login for this account.
            chat_history_collection.delete_many({"customer_id": str(customer_id)})
        except Exception as e:
            print(f"Logout chat cleanup error: {e}")
    session.clear()
    return redirect(url_for("login"))


@app.route("/home")
def home():
    user_name = session.get("user_name", "Guest")
    featured = PRODUCTS["men"][:2] + PRODUCTS["women"][:2] + PRODUCTS["kids"][:2]
    return render_template("home.html", user_name=user_name, featured_products=featured)


@app.route("/shop")
@app.route("/shop/<category>")
def shop(category=None):
    user_name = session.get("user_name", "Guest")

    if category and category in PRODUCTS:
        products = PRODUCTS[category]
    else:
        products = []
        for category_products in PRODUCTS.values():
            products.extend(category_products)

    return render_template("shop.html", user_name=user_name, products=products, category=category)


@app.route("/product/<int:product_id>")
def product_detail(product_id):
    user_name = session.get("user_name", "Guest")
    product = None

    for category_products in PRODUCTS.values():
        for p in category_products:
            if p["id"] == product_id:
                product = p
                break
        if product:
            break

    return render_template("product.html", user_name=user_name, product=product)


@app.route("/profile")
@login_required
def profile():
    user_name = session.get("user_name", "Guest")
    customer_id = session.get("customer_id")
    customer = None

    if document_store_enabled():
        customer = get_document_profile_by_customer_id(customer_id)

    if not customer and Config.DOCUMENT_BACKEND == "disabled" and oracle_available:
        try:
            connection = get_oracle_connection()
            cursor = connection.cursor()
            cursor.execute("""
                SELECT profile_json
                FROM customer_profile_oracle
                WHERE customer_id = :customer_id
            """, {"customer_id": customer_id})
            row = cursor.fetchone()
            cursor.close()
            connection.close()

            if row and row[0]:
                raw_json = row[0].read() if hasattr(row[0], "read") else row[0]
                customer = json.loads(raw_json)
        except Exception as e:
            print(f"Oracle profile error: {e}")

    if not customer:
        flash("Profile not found.", "error")
        return redirect(url_for("home"))

    return render_template("profile.html", user_name=user_name, customer=customer)


# =========================================================
# CHAT APIS
# =========================================================

@app.route("/api/chat", methods=["POST"])
@login_required
def chat():
    data = request.get_json() or {}
    user_message = str(data.get("message", "")).strip()

    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    try:
        direct_profile_response = direct_profile_request(
            user_message, session.get("customer_id")
        )
        if direct_profile_response:
            conversation_id = session.get("select_ai_conversation_id", "")
            save_chat_message(
                session.get("customer_id", 0),
                user_message,
                direct_profile_response,
            )
            return jsonify({
                "response": direct_profile_response,
                "timestamp": now_iso(),
                "conversation_id": conversation_id,
            })

        # Explicit add requests must run before quantity-management handling.
        # Otherwise a phrase such as "add SKU X, quantity 1" is interpreted
        # as "set the existing item's quantity to 1".
        direct_add_response = direct_cart_request(
            user_message, session.get("customer_id")
        )
        if direct_add_response:
            conversation_id = session.get("select_ai_conversation_id", "")
            save_chat_message(
                session.get("customer_id", 0),
                user_message,
                direct_add_response,
            )
            return jsonify({
                "response": direct_add_response,
                "timestamp": now_iso(),
                "conversation_id": conversation_id,
            })

        direct_cart_management_response = direct_cart_management_request(
            user_message, session.get("customer_id")
        )
        if direct_cart_management_response:
            conversation_id = session.get("select_ai_conversation_id", "")
            save_chat_message(
                session.get("customer_id", 0),
                user_message,
                direct_cart_management_response,
            )
            return jsonify({
                "response": direct_cart_management_response,
                "timestamp": now_iso(),
                "conversation_id": conversation_id,
            })

        direct_contents_response = direct_cart_contents_request(user_message, session.get("customer_id"))
        if direct_contents_response:
            conversation_id = session.get("select_ai_conversation_id", "")
            save_chat_message(session.get("customer_id", 0), user_message, direct_contents_response)
            return jsonify({
                "response": direct_contents_response,
                "timestamp": now_iso(),
                "conversation_id": conversation_id,
            })

        direct_faq_response = direct_faq_request(user_message)
        if direct_faq_response:
            conversation_id = session.get("select_ai_conversation_id", "")
            save_chat_message(session.get("customer_id", 0), user_message, direct_faq_response)
            return jsonify({
                "response": direct_faq_response,
                "timestamp": now_iso(),
                "conversation_id": conversation_id,
            })

        profile_context = format_chat_profile_context(
            get_chat_profile(session.get("customer_id"))
        )
        cart = get_customer_cart(session.get("customer_id"))
        cart_items = (cart or {}).get("cart_items", [])
        cart_context = "empty"
        if cart_items:
            cart_context = "; ".join(
                f"{item.get('title', item.get('sku', 'Product'))} "
                f"(SKU {item.get('sku', '')}, quantity {item.get('quantity', 1)}, "
                + "$"
                + f"{cart_item_unit_price(item):.2f} each, line total "
                + "$"
                + f"{float(item.get('total', 0) or 0):.2f})"
                for item in cart_items
            )

        full_user_message = (
            "Context information: "
            + "Customer Name: " + str(session.get("user_name", ""))
            + " ; Session Cookie: " + str(request.cookies.get("session"))
            + " ; customer_id: " + str(session.get("customer_id"))
            + " ; Authenticated customer profile: " + profile_context
            + " ; Current shopping cart: " + cart_context
            + " . Response language: " + detect_response_language(user_message)
            + ". Always answer in the response language, using natural conversational wording."
            + " The cart context is authoritative; for cart questions, answer from it and do not ask for the customer name."
            + " . User prompt: " + str(user_message)
        )

        conversation_id = session.get("select_ai_conversation_id", "")
        conversation_id, response_text = run_ai_agent_team(full_user_message, conversation_id)

        if response_text is None:
            response_text = "No response returned from AI agent team."
        response_text = str(response_text).strip() or "AI agent team returned an empty response."

        remembered_skus = extract_product_skus(response_text)
        if 0 < len(remembered_skus) <= 3:
            session["last_recommended_skus"] = remembered_skus
            session["last_recommended_details"] = extract_recommendation_details(response_text)

        save_chat_message(session.get("customer_id", 0), user_message, response_text)

        return jsonify({
            "response": response_text,
            "timestamp": now_iso(),
            "conversation_id": conversation_id
        })

    except Exception as e:
        print(f"Chat error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Chat service unavailable", "details": str(e)}), 500


@app.route("/api/chat/clear", methods=["POST"])
@login_required
def clear_chat():
    try:
        customer_id = session.get("customer_id", 0)
        if document_chat_enabled():
            chat_history_collection.delete_many({"customer_id": str(customer_id)})
        session["select_ai_conversation_id"] = ""
        session["last_recommended_skus"] = []
        session["last_recommended_details"] = {}
        return jsonify({"status": "success", "message": "Chat history cleared"})
    except Exception as e:
        print(f"Clear chat error: {str(e)}")
        return jsonify({"error": "Failed to clear chat history"}), 500


@app.route("/api/chat/history", methods=["GET"])
@login_required
def chat_history():
    customer_id = session.get("customer_id", 0)

    if not customer_id:
        return jsonify({"success": False, "message": "Authentication required"}), 401

    try:
        history = []
        if document_chat_enabled():
            docs = get_chat_history(customer_id)
            for doc in docs:
                history.append({
                    "user_message": str(doc.get("message", "")),
                    "assistant_message": str(doc.get("response", "")),
                    "timestamp": doc.get("chat_timestamp")
                })

        return jsonify({"success": True, "history": history}), 200

    except Exception as e:
        print(f"Chat history error: {str(e)}")
        return jsonify({"success": False, "error": "Failed to load chat history", "details": str(e)}), 500


# =========================================================
# CART ROUTES / APIS
# =========================================================

@app.route("/cart")
@login_required
def cart():
    user_name = session.get("user_name", "Guest")
    customer_id = session.get("customer_id")
    cart_data = get_customer_cart(customer_id) if customer_id else None
    return render_template("cart.html", user_name=user_name, cart=cart_data, customer_id=customer_id)


@app.route("/api/v1/cart", methods=["GET"])
@api_login_required
def api_get_cart():
    customer_id = session.get("customer_id")
    cart = get_customer_cart(customer_id)
    if not cart:
        return jsonify({"success": False, "message": "No active cart found"}), 404
    return jsonify({"success": True, "data": cart}), 200


@app.route("/api/v1/cart", methods=["POST"])
@api_login_required
def api_create_cart():
    try:
        customer_id = session.get("customer_id")
        existing_cart = get_customer_cart(customer_id)
        if existing_cart:
            return jsonify({"success": True, "message": "Active cart already exists", "data": existing_cart}), 200

        if document_cart_enabled():
            new_cart = empty_cart_document(customer_id)
            shopping_cart_collection.insert_one(new_cart)
            created_cart = get_customer_cart(customer_id)
            return jsonify({"success": True, "message": "Cart created successfully", "data": created_cart}), 201

        return jsonify({"success": False, "error": "Document cart is not enabled"}), 500

    except Exception as e:
        print(f"Error creating cart: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/v1/cart/items", methods=["POST"])
@api_login_required
def api_add_cart_item():
    try:
        customer_id = session.get("customer_id")
        data = request.json or {}

        if not document_cart_enabled():
            return jsonify({"success": False, "error": "Document cart is not enabled"}), 500

        # only shopper-facing minimum
        if not data.get("quantity"):
            data["quantity"] = 1

        if not data.get("product_id") and not data.get("sku") and not data.get("title"):
            return jsonify({
                "success": False,
                "error": "MISSING_PRODUCT_IDENTIFIER",
                "message": "Provide at least product_id, sku, or title"
            }), 400

        # resolve missing backend fields from catalog
        catalog_product = resolve_product_from_catalog(
            product_id=data.get("product_id"),
            sku=data.get("sku"),
            title=data.get("title")
        )

        if catalog_product:
            data["product_id"] = data.get("product_id") or catalog_product["product_id"]
            data["sku"] = data.get("sku") or catalog_product["sku"]
            data["title"] = data.get("title") or catalog_product["title"]
            data["category"] = data.get("category") or catalog_product["category"]
            data["brand"] = data.get("brand") or catalog_product["brand"]
            data["price"] = data.get("price", catalog_product["price"])
            data["discount_percentage"] = data.get("discount_percentage", catalog_product["discount_percentage"])
            data["image_url"] = data.get("image_url") or catalog_product["image_url"]
            if "in_stock" not in data or data.get("in_stock") in (None, "", []):
                data["in_stock"] = catalog_product["in_stock"]

        required_fields = ["product_id", "title", "price", "quantity"]
        missing_fields = [field for field in required_fields if field not in data or data.get(field) in (None, "", [])]
        if missing_fields:
            return jsonify({
                "success": False,
                "error": "MISSING_REQUIRED_FIELDS",
                "message": "Missing required fields for add to cart",
                "missing_fields": missing_fields
            }), 400

        cart = get_customer_cart(customer_id)

        discount_percentage = float(data.get("discount_percentage", 0) or 0)
        price = float(data["price"])
        discounted_price = round(price * (1 - discount_percentage / 100), 2)
        quantity = int(data.get("quantity", 1) or 1)

        cart_item = {
            "product_id": str(data["product_id"]),
            "sku": data.get("sku", str(data["product_id"])),
            "title": data["title"],
            "category": data.get("category", ""),
            "color": data.get("color", ""),
            "size": data.get("size", ""),
            "brand": data.get("brand", ""),
            "price": price,
            "quantity": quantity,
            "discount_percentage": discount_percentage,
            "discounted_price": discounted_price,
            "total": round(discounted_price * quantity, 2),
            "image_url": data.get("image_url", ""),
            "in_stock": bool(data.get("in_stock", True)),
            "added_at": now_iso()
        }

        item_exists = False
        for item in cart["cart_items"]:
            same_product = str(item.get("product_id")) == str(cart_item["product_id"])
            same_size = str(item.get("size", "")) == str(cart_item["size"])
            same_color = str(item.get("color", "")) == str(cart_item["color"])

            if same_product and same_size and same_color:
                item["quantity"] = int(item["quantity"]) + quantity
                item["total"] = round(float(item["discounted_price"]) * int(item["quantity"]), 2)
                item_exists = True
                break

        if not item_exists:
            cart["cart_items"].append(cart_item)

        cart["pricing"] = calculate_cart_pricing(cart["cart_items"])
        save_customer_cart(cart)

        updated_cart = get_customer_cart(customer_id)
        return jsonify({
            "success": True,
            "message": "Item added to cart successfully",
            "data": updated_cart
        }), 200

    except Exception as e:
        error_message = str(e)
        print(f"Error adding item to cart: {error_message}")
        return jsonify({
            "success": False,
            "error": "ADD_TO_CART_FAILED",
            "message": error_message
        }), 500

@app.route("/api/v1/cart/items/<product_id>", methods=["PATCH"])
@api_login_required
def api_update_cart_item(product_id):
    try:
        customer_id = session.get("customer_id")
        data = request.json or {}

        if "quantity" not in data:
            return jsonify({"success": False, "error": "Quantity is required"}), 400

        quantity = int(data["quantity"])
        if quantity < 1:
            return jsonify({"success": False, "error": "Quantity must be at least 1"}), 400
        if quantity > 10:
            return jsonify({"success": False, "error": "Quantity cannot exceed 10"}), 400

        success = update_cart_item_quantity(customer_id, product_id, quantity)
        if not success:
            return jsonify({"success": False, "message": "Failed to update item quantity"}), 404

        cart = get_customer_cart(customer_id)
        return jsonify({"success": True, "message": "Item quantity updated successfully", "data": cart}), 200

    except Exception as e:
        print(f"Error updating cart item: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/v1/cart/items/<product_id>", methods=["DELETE"])
@api_login_required
def api_remove_cart_item(product_id):
    try:
        customer_id = session.get("customer_id")
        success = remove_cart_item_from_document_store(customer_id, product_id)
        if not success:
            return jsonify({"success": False, "message": "Failed to remove item from cart"}), 404

        cart = get_customer_cart(customer_id)
        return jsonify({"success": True, "message": "Item removed from cart successfully", "data": cart}), 200

    except Exception as e:
        print(f"Error removing cart item: {e}")
        return jsonify({"success": False, "error": str(e)}), 500



# =========================================================
# ADMIN ROUTES
# =========================================================

@app.route("/admin")
def admin_dashboard():
    user_name = session.get("user_name", "Admin")

    if document_store_enabled():
        total_customers = customers_collection.count_documents({})
        pipeline = [{
            "$group": {
                "_id": None,
                "total_revenue": {"$sum": "$purchaseHistory.lifetimeValue"},
                "total_orders": {"$sum": "$purchaseHistory.totalOrders"},
                "avg_order_value": {"$avg": "$purchaseHistory.averageOrderValue"}
            }
        }]
        stats = list(customers_collection.aggregate(pipeline))
    else:
        total_customers = 0
        stats = []

    dashboard_stats = {
        "total_customers": total_customers,
        "total_revenue": stats[0]["total_revenue"] if stats else 0,
        "total_orders": stats[0]["total_orders"] if stats else 0,
        "avg_order_value": stats[0]["avg_order_value"] if stats else 0
    }

    return render_template("admin/dashboard.html", user_name=user_name, stats=dashboard_stats)


@app.route("/admin/customers")
def admin_customers():
    user_name = session.get("user_name", "Admin")
    customers = list(customers_collection.find().limit(100)) if document_store_enabled() else []
    return render_template("admin/customers.html", user_name=user_name, customers=customers)


@app.route("/admin/orders")
def admin_orders():
    user_name = session.get("user_name", "Admin")
    if document_store_enabled():
        customers = list(
            customers_collection.find({"purchaseHistory.totalOrders": {"$gt": 0}})
            .sort("purchaseHistory.lastOrderDate", -1)
            .limit(50)
        )
    else:
        customers = []
    return render_template("admin/orders.html", user_name=user_name, customers=customers)


# =========================================================
# ARTICLES / FAQ
# =========================================================

ARTICLES_DIR = Path("content/articles")
FAQ_FILE = Path(__file__).parent / "content" / "faq.md"


def get_article_metadata(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            metadata = yaml.safe_load(parts[1])
            article_content = parts[2].strip()
            return metadata, article_content
    return {}, content


def load_articles():
    articles = []
    if not ARTICLES_DIR.exists():
        ARTICLES_DIR.mkdir(parents=True, exist_ok=True)
        return []

    md_files = list(ARTICLES_DIR.glob("*.md"))
    for filepath in md_files:
        try:
            metadata, content = get_article_metadata(filepath)
            if not metadata:
                continue

            html_content = markdown.markdown(content, extensions=["extra", "codehilite", "toc"])
            date_value = metadata.get("date", datetime.now())

            try:
                if isinstance(date_value, str):
                    pub_date = datetime.strptime(date_value, "%Y-%m-%d")
                elif isinstance(date_value, datetime):
                    pub_date = date_value
                else:
                    from datetime import date as date_type
                    if isinstance(date_value, date_type):
                        pub_date = datetime.combine(date_value, datetime.min.time())
                    else:
                        pub_date = datetime.now()
            except Exception:
                pub_date = datetime.now()

            tags = metadata.get("tags", "")
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",")]
            elif not isinstance(tags, list):
                tags = []

            articles.append({
                "_id": metadata.get("slug", filepath.stem),
                "title": metadata.get("title", "Untitled"),
                "slug": metadata.get("slug", filepath.stem),
                "category": metadata.get("category", "General"),
                "summary": metadata.get("summary", ""),
                "content": html_content,
                "featuredImage": metadata.get("image", ""),
                "author": metadata.get("author", "Anonymous"),
                "status": "published",
                "tags": tags,
                "publishedDate": pub_date,
                "views": 0,
                "filepath": filepath,
            })
        except Exception as e:
            print(f"Error loading article {filepath}: {e}")

    articles.sort(key=lambda x: x["publishedDate"], reverse=True)
    return articles


def get_article_by_slug(slug):
    for article in load_articles():
        if article["slug"] == slug or article["_id"] == slug:
            return article
    return None


def load_faq():
    if not FAQ_FILE.exists():
        return {
            "title": "FAQ",
            "description": "Frequently Asked Questions",
            "content": "<p>FAQ content not found.</p>",
            "sections": [],
        }

    try:
        with open(FAQ_FILE, "r", encoding="utf-8") as f:
            content = f.read()

        metadata = {}
        faq_content = content

        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                metadata = yaml.safe_load(parts[1])
                faq_content = parts[2].strip()

        html_content = markdown.markdown(faq_content, extensions=["extra", "toc", "codehilite"])

        sections = []
        for line in faq_content.split("\n"):
            if line.startswith("## "):
                section_title = line.replace("## ", "").strip()
                section_id = section_title.lower().replace(" ", "-").replace("&", "and")
                sections.append({"title": section_title, "id": section_id})

        return {
            "title": metadata.get("title", "FAQ"),
            "description": metadata.get("description", ""),
            "content": html_content,
            "sections": sections,
            "last_updated": metadata.get("last_updated", ""),
        }
    except Exception as e:
        print(f"Error loading FAQ: {e}")
        return {
            "title": "FAQ",
            "description": "Frequently Asked Questions",
            "content": "<p>Error loading FAQ content.</p>",
            "sections": [],
        }


@app.route("/articles")
def articles_list():
    user_name = session.get("user_name", "Guest")
    return render_template("articles/list.html", user_name=user_name, articles=load_articles())


@app.route("/articles/<article_id>")
def article_detail(article_id):
    user_name = session.get("user_name", "Guest")
    article = get_article_by_slug(article_id)
    if not article:
        return redirect(url_for("articles_list"))
    return render_template("articles/detail.html", user_name=user_name, article=article)


@app.route("/articles/category/<category>")
def articles_by_category(category):
    user_name = session.get("user_name", "Guest")
    all_articles = load_articles()
    articles = [a for a in all_articles if a["category"] == category]
    return render_template("articles/list.html", user_name=user_name, articles=articles, current_category=category)


@app.route("/faq")
def faq():
    user_name = session.get("user_name", "Guest")
    faq_data = load_faq()
    return render_template("faq.html", user_name=user_name, faq=faq_data)


@app.route("/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "fashion-store-api",
        "oracle_available": oracle_available,
        "document_backend_available": document_store_enabled(),
        "timestamp": now_iso()
    }), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
