---
title: Frequently Asked Questions
description: Find answers to common questions about shopping, shipping, returns, and more.
last_updated: 2025-11-26
---

# Frequently Asked Questions

Find answers to the most common questions about shopping with us.

## Orders & Payment

### How do I place an order?
Browse our collections, add items to your cart, and proceed to checkout. You'll need to provide shipping information and payment details to complete your purchase.

### What payment methods do you accept?
We accept all major credit cards (Visa, Mastercard, American Express, Discover), PayPal, Apple Pay, and Google Pay. All transactions are secured with SSL encryption.

### Can I modify or cancel my order?
Orders can be modified or cancelled within 1 hour of placement. Contact our customer service team immediately at support@fashionstore.com or use the chat assistant for fastest response.

### Do you offer gift cards?
Yes! Gift cards are available in denominations of $25, $50, $100, and $250. They never expire and can be used for any purchase on our website.

### Why was my payment declined?
Payment declines can occur for several reasons: insufficient funds, incorrect card details, or your bank's fraud protection. Please verify your information or contact your bank. You can also try an alternative payment method.

## Shipping & Delivery

### What are your shipping options?
- **Standard Shipping (3-5 business days)**: FREE on orders over $75, otherwise $5.99
- **Express Shipping (1-2 business days)**: $14.99
- **Next Day Delivery**: $24.99 (orders placed before 2 PM)

### Do you ship internationally?
Currently, we ship within the United States. International shipping is coming soon! Sign up for our newsletter to be notified when we expand.

### How can I track my order?
Once your order ships, you'll receive a tracking number via email. You can also track your order from the "My Orders" section in your account profile.

### What if my package is lost or damaged?
If your package is lost or arrives damaged, please contact us within 48 hours with photos if applicable. We'll arrange a replacement or full refund immediately.

### Can I change my shipping address after ordering?
If your order hasn't shipped yet, contact us immediately and we'll update your address. Once shipped, please contact the carrier directly to arrange delivery changes.

## Returns & Exchanges

### What is your return policy?
We offer a **30-day return policy** from the date of delivery. Items must be unworn, unwashed, with original tags attached, and in original packaging.

### How do I return an item?
1. Log into your account and go to "My Orders"
2. Select the order and click "Return Item"
3. Print the prepaid return label
4. Pack the item securely
5. Drop off at any USPS location

### Are returns free?
Returns are FREE for all orders. We provide a prepaid return shipping label for your convenience.

### How long does it take to process a refund?
Refunds are processed within 3-5 business days after we receive your return. The refund will be credited to your original payment method. Please allow an additional 5-7 business days for the credit to appear in your account.

### Can I exchange an item?
Yes! We offer free exchanges for different sizes or colors. Follow the return process and indicate your exchange preference. We'll ship your new item as soon as we receive the return.

### What items cannot be returned?
For hygiene reasons, underwear, swimwear, and earrings are final sale unless defective. Sale items marked "Final Sale" are also non-returnable.

## Sizing & Fit

### How do I find my size?
Each product page has a detailed size guide. Click "Size Guide" next to the size selector to view measurements. If you're between sizes, we recommend sizing up for a more comfortable fit.

### Do your sizes run true to size?
Most of our items run true to size. However, sizing can vary by brand and style. Always check the specific size guide on each product page and read customer reviews for fit feedback.

### Can I get help choosing the right size?
Absolutely! Our chat assistant can help with sizing questions, or contact our customer service team. We're happy to provide detailed measurements for any item.

### What if the size doesn't fit?
No problem! We offer free exchanges. Simply return the item and select your new size. We'll ship it to you at no additional cost.

## Product Information

### Are your clothes sustainable?
We're committed to sustainability! Look for our "Eco-Friendly" badge on product pages. We partner with brands that use organic materials, recycled fabrics, and ethical manufacturing practices.

### How do I care for my clothes?
Care instructions are provided on the product page and on the garment's care label. Generally:
- Wash in cold water
- Turn inside out
- Use gentle cycle
- Air dry when possible
- Iron on low heat if needed

### Are your product photos accurate?
We strive for accuracy, but colors may vary slightly due to screen settings. We provide multiple photos from different angles and detailed product descriptions to help you make informed decisions.

### Do you restock sold-out items?
Popular items are often restocked! Click "Notify Me" on sold-out product pages to receive an email when they're back in stock.

## Account & Loyalty Program

### Do I need an account to shop?
No, you can checkout as a guest. However, creating an account allows you to:
- Track orders easily
- Save favorite items
- Store multiple shipping addresses
- Earn loyalty points
- Get exclusive offers

### What is your loyalty program?
Our loyalty program has four tiers:
- **Bronze**: 0-999 points
- **Silver**: 1,000-4,999 points
- **Gold**: 5,000-9,999 points
- **Platinum**: 10,000+ points

Earn 1 point per dollar spent. Higher tiers unlock exclusive discounts, early access to sales, and free shipping upgrades.

### How do I check my loyalty points?
Log into your account and visit the "My Profile" page to view your current points balance and tier status.

### Do loyalty points expire?
Points remain active as long as you make a purchase at least once every 12 months. Inactive accounts will have points reset.

## Privacy & Security

### Is my personal information secure?
Yes! We use industry-standard SSL encryption to protect your data. We never store complete credit card information, and we never share your personal information with third parties without your consent.

### How do you use my email address?
We use your email for order confirmations, shipping updates, and account notifications. If you opt-in, you'll also receive our newsletter with exclusive offers and style tips. You can unsubscribe anytime.

### Can I delete my account?
Yes. Contact customer service at support@fashionstore.com to request account deletion. All personal information will be permanently removed within 30 days.

## Promotions & Discounts

### Can I use multiple promo codes?
Only one promo code can be applied per order. The code with the highest discount will automatically be applied.

### Do you offer student discounts?
Yes! Students receive 15% off with valid student ID verification. Sign up through our student discount program page.

### When do sales happen?
We have seasonal sales (Spring, Summer, Fall, Winter), holiday promotions, and flash sales. Follow us on social media or sign up for our newsletter to stay updated.

### Does free shipping apply to sale items?
Yes! Our free shipping threshold ($75+) applies to all items, including sale items.

## Customer Service

### How can I contact customer service?
- **Chat Assistant**: Available 24/7 on our website
- **Email**: support@fashionstore.com (response within 24 hours)
- **Phone**: 1-800-FASHION (Mon-Fri, 9 AM - 6 PM EST)

### What are your customer service hours?
Email support: 24/7 (response within 24 hours)
Phone support: Monday-Friday, 9 AM - 6 PM EST
Chat assistant: 24/7 automated assistance

### I have a complaint. How do I submit it?
We take all feedback seriously. Email complaints@fashionstore.com or call our customer service line. We'll respond within 24 hours and work to resolve any issues.

## Still Have Questions?

Can't find the answer you're looking for? Our customer service team is here to help!

- **Use our Chat Assistant** (bottom right corner)
- **Email us** at support@fashionstore.com
- **Call us** at 1-800-FASHION

We're committed to providing excellent customer service and ensuring you have the best shopping experience!
