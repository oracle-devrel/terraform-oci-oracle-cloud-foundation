# Shopping Cart REST API Documentation

Base URL: `http://localhost:5000/api/v1`

All endpoints require authentication via session cookie.

## Endpoints

### 1. Get Cart
**GET** `/cart`

Get the active shopping cart for the logged-in customer.

**Response (200):**
{
"success": true,
"data": {
"cart_id": "cart_8f3a42bc",
"customer_id": "393",
"cart_items": [...],
"pricing": {...}
}
}


---

### 2. Create/Initialize Cart
**POST** `/cart`

Create a new shopping cart or return existing active cart.

**Response (201):**
{
"success": true,
"message": "Cart created successfully",
"data": {...}
}


---

### 3. Add Item to Cart
**POST** `/cart/items`

Add an item to the cart or update quantity if item already exists.

**Request Body:**
{
"product_id": "DRESS_001",
"sku": "WD-BLK-M-2025",
"title": "Women's Silk Evening Dress",
"category": "Dresses",
"color": "Black",
"size": "M",
"brand": "Elegance Collection",
"price": 129.99,
"quantity": 1,
"discount_percentage": 15,
"image_url": "https://cdn.example.com/products/dress-001.jpg",
"in_stock": true
}


**Response (200):**
{
"success": true,
"message": "Item added to cart successfully",
"data": {...}
}


---

### 4. Update Item Quantity
**PATCH** `/cart/items/{product_id}`

Update the quantity of a specific item in the cart.

**Request Body:**
{
"quantity": 3
}


**Response (200):**
{
"success": true,
"message": "Item quantity updated successfully",
"data": {...}
}


---

### 5. Remove Item from Cart
**DELETE** `/cart/items/{product_id}`

Remove a specific item from the cart.

**Response (200):**
{
"success": true,
"message": "Item removed from cart successfully",
"data": {...}
}


---

### 6. Clear Cart
**POST** `/cart/clear`

Remove all items from the cart.

**Response (200):**
{
"success": true,
"message": "Cart cleared successfully",
"data": {...}
}


---

### 7. Update Shipping Address
**PUT** `/cart/shipping-address`

Update the shipping address for the cart.

**Request Body:**
{
"recipient_name": "Jane Smith",
"street": "123 Fashion Ave",
"city": "New York",
"state": "NY",
"postal_code": "10001",
"country": "USA"
}


**Response (200):**
{
"success": true,
"message": "Shipping address updated successfully",
"data": {...}
}


---

### 8. Apply Coupon
**POST** `/cart/coupons`

Apply a coupon code to the cart.

**Request Body:**
{
"coupon_code": "FASHION15",
"discount_type": "percentage",
"discount_value": 15,
"applied_to": ["DRESS_001"]
}


**Response (200):**
{
"success": true,
"message": "Coupon applied successfully",
"data": {...}
}


---

### 9. Remove Coupon
**DELETE** `/cart/coupons/{coupon_code}`

Remove a coupon from the cart.

**Response (200):**
{
"success": true,
"message": "Coupon removed successfully",
"data": {...}
}


---

### 10. Get Cart Summary
**GET** `/cart/summary`

Get a summary of the cart (item count, total, etc.).

**Response (200):**
{
"success": true,
"data": {
"item_count": 2,
"total_items": 3,
"subtotal": 331.47,
"discount_total": 58.5,
"tax": 26.52,
"shipping": 0,
"total": 357.99,
"currency": "USD"
}
}


## Error Responses

**401 Unauthorized:**
{
"success": false,
"error": "Authentication required",
"message": "Please log in to access this resource"
}


**400 Bad Request:**
{
"success": false,
"error": "Missing required field: product_id"
}


**404 Not Found:**
{
"success": false,
"message": "No active cart found"
}


**500 Internal Server Error:**
{
"success": false,
"error": "Error message here"
}


# Test with curl **************************************

# 1. Get cart
curl -X GET http://localhost:5000/api/v1/cart \
  -H "Cookie: session=your_session_cookie"

# 2. Add item to cart
curl -X POST http://localhost:5000/api/v1/cart/items \
  -H "Content-Type: application/json" \
  -H "Cookie: session=your_session_cookie" \
  -d '{
    "product_id": "DRESS_001",
    "title": "Women'\''s Silk Evening Dress",
    "price": 129.99,
    "quantity": 1,
    "discount_percentage": 15
  }'

# 3. Update item quantity
curl -X PATCH http://localhost:5000/api/v1/cart/items/DRESS_001 \
  -H "Content-Type: application/json" \
  -H "Cookie: session=your_session_cookie" \
  -d '{"quantity": 3}'

# 4. Remove item
curl -X DELETE http://localhost:5000/api/v1/cart/items/DRESS_001 \
  -H "Cookie: session=your_session_cookie"

# 5. Get cart summary
curl -X GET http://localhost:5000/api/v1/cart/summary \
  -H "Cookie: session=your_session_cookie"