# Fashion Retail Web Application

A modern, full-featured e-commerce platform for a fashion retailer built with Flask, MongoDB Atlas, and Oracle Autonomous Database.

## Features

- **Modern UI/UX**: Trendy, colorful, and engaging design with responsive layout
- **Customer Portal**: Browse products, view profile, manage cart
- **Admin Dashboard**: Customer management, order tracking, analytics
- **Chat Assistant**: AI-powered chat widget with Oracle Database integration
- **MongoDB Integration**: Customer profiles stored in MongoDB Atlas
- **Oracle Database**: Chat history and analytics stored in Oracle Autonomous Database
- **User Authentication**: Email-based login system
- **Product Catalog**: Men's, women's, and children's clothing categories

## Technology Stack

- **Backend**: Python 3.9+, Flask 3.0
- **Databases**: 
  - MongoDB Atlas (customer profiles)
  - Oracle Autonomous Database (chat history)
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Deployment**: Oracle Linux VM

## Installation

### Automated Installation (Oracle Linux)