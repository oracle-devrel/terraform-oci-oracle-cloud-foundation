#!/bin/bash

# Fashion Retail Application Installation Script for Oracle Linux
# This script automates the installation and setup process

set -e  # Exit on error

echo "========================================="
echo "Fashion Retail App Installation Script"
echo "========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

# Update system
echo "[1/10] Updating system packages..."
dnf update -y

# Install Python 3.9+
echo "[2/10] Installing Python 3.9..."
dnf install -y python39 python39-pip python39-devel

# Install system dependencies
echo "[3/10] Installing system dependencies..."
dnf install -y gcc gcc-c++ make libaio wget unzip

# Install Oracle Instant Client
echo "[4/10] Installing Oracle Instant Client..."
cd /tmp
wget https://download.oracle.com/otn_software/linux/instantclient/219000/instantclient-basic-linux.x64-21.9.0.0.0dbru.zip
wget https://download.oracle.com/otn_software/linux/instantclient/219000/instantclient-sqlplus-linux.x64-21.9.0.0.0dbru.zip

mkdir -p /opt/oracle
cd /opt/oracle
unzip /tmp/instantclient-basic-linux.x64-21.9.0.0.0dbru.zip
unzip /tmp/instantclient-sqlplus-linux.x64-21.9.0.0.0dbru.zip

# Set Oracle environment variables
echo "export LD_LIBRARY_PATH=/opt/oracle/instantclient_21_9:\$LD_LIBRARY_PATH" >> /etc/profile.d/oracle.sh
echo "export PATH=/opt/oracle/instantclient_21_9:\$PATH" >> /etc/profile.d/oracle.sh
source /etc/profile.d/oracle.sh

# Create application directory
echo "[5/10] Creating application directory..."
APP_DIR="/opt/fashion-retail-app"
mkdir -p $APP_DIR
cd $APP_DIR

# Create Oracle wallet directory
echo "[6/10] Creating Oracle wallet directory..."
mkdir -p /opt/oracle/wallet
chmod 755 /opt/oracle/wallet

echo "NOTE: Place your Oracle Autonomous Database wallet files in /opt/oracle/wallet"

# Install Python dependencies
echo "[7/10] Installing Python dependencies..."
cat > requirements.txt << 'EOF'
Flask==3.0.0
Flask-Session==0.5.0
pymongo==4.6.0
cx_Oracle==8.3.0
dnspython==2.4.2
Werkzeug==3.0.1
python-dotenv==1.0.0
gunicorn==21.2.0
EOF

python3.9 -m pip install --upgrade pip
python3.9 -m pip install -r requirements.txt

# Create environment file template
echo "[8/10] Creating environment configuration..."
cat > .env << 'EOF'
# Flask Configuration
SECRET_KEY=change-this-to-random-secret-key

# MongoDB Atlas Configuration
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/fashion_store?retryWrites=true&w=majority
MONGO_DBNAME=fashion_store

# Oracle Autonomous Database Configuration
ORACLE_USER=ADMIN
ORACLE_PASSWORD=YourPassword123
ORACLE_DSN=yourdb_high
ORACLE_WALLET_LOCATION=/opt/oracle/wallet

# Flask App Settings
FLASK_ENV=production
FLASK_DEBUG=False
EOF

echo "IMPORTANT: Edit /opt/fashion-retail-app/.env with your actual credentials"

# Create systemd service
echo "[9/10] Creating systemd service..."
cat > /etc/systemd/system/fashion-retail.service << 'EOF'
[Unit]
Description=Fashion Retail Web Application
After=network.target

[Service]
Type=notify
User=root
WorkingDirectory=/opt/fashion-retail-app
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
ExecStart=/usr/local/bin/gunicorn --workers 4 --bind 0.0.0.0:5000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Configure firewall
echo "[10/10] Configuring firewall..."
firewall-cmd --permanent --add-port=5000/tcp
firewall-cmd --reload

# Set permissions
chmod -R 755 $APP_DIR
chown -R root:root $APP_DIR

echo ""
echo "========================================="
echo "Installation Complete!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Upload your Oracle wallet files to: /opt/oracle/wallet"
echo "2. Edit configuration file: nano /opt/fashion-retail-app/.env"
echo "3. Copy application files to: /opt/fashion-retail-app/"
echo "4. Initialize the database schema:"
echo "   cd /opt/fashion-retail-app"
echo "   python3.9 db_connection.py"
echo "5. Start the application:"
echo "   systemctl start fashion-retail"
echo "   systemctl enable fashion-retail"
echo "6. Check status:"
echo "   systemctl status fashion-retail"
echo "7. View logs:"
echo "   journalctl -u fashion-retail -f"
echo ""
echo "Application will be available at: http://YOUR_SERVER_IP:5000"
echo ""
