from flask import Flask, render_template

app = Flask(__name__)
app.config['SECRET_KEY'] = 'test-key'

@app.route('/')
def test():
    return "<h1>Flask is Working!</h1>"

@app.route('/template')
def test_template():
    return render_template('test.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
