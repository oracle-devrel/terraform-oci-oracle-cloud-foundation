// Chat Widget Functionality
document.addEventListener('DOMContentLoaded', function() {
    const chatWidget = document.getElementById('chatWidget');
    const chatToggleBtn = document.getElementById('chatToggleBtn');
    const toggleChatBtn = document.getElementById('toggleChatBtn');
    const clearChatBtn = document.getElementById('clearChatBtn');
    const chatInput = document.getElementById('chatInput');
    const sendChatBtn = document.getElementById('sendChatBtn');
    const chatBody = document.getElementById('chatBody');

    if (chatToggleBtn) {
        chatToggleBtn.addEventListener('click', function() {
            chatWidget.classList.toggle('active');
        });
    }

    if (toggleChatBtn) {
        toggleChatBtn.addEventListener('click', function() {
            chatWidget.classList.remove('active');
        });
    }

    if (clearChatBtn) {
        clearChatBtn.addEventListener('click', async function() {
            if (confirm('Are you sure you want to clear the chat history?')) {
                try {
                    const response = await fetch('/api/chat/clear', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });

                    if (response.ok) {
                        // Clear chat messages from UI
                        chatBody.innerHTML = '<div class="chat-message bot-message"><p>Chat history cleared. How can I help you?</p></div>';
                    } else {
                        alert('Failed to clear chat history');
                    }
                } catch (error) {
                    console.error('Error clearing chat:', error);
                    alert('Error clearing chat history');
                }
            }
        });
    }

    async function sendMessage() {
        const message = chatInput.value.trim();
        
        if (!message) return;

        // Add user message to chat
        const userMessageDiv = document.createElement('div');
        userMessageDiv.className = 'chat-message user-message';
        userMessageDiv.innerHTML = `<p>${message}</p>`;
        chatBody.appendChild(userMessageDiv);

        // Clear input
        chatInput.value = '';

        // Scroll to bottom
        chatBody.scrollTop = chatBody.scrollHeight;

        // Send to server
        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            });

            const data = await response.json();

            // Add bot response
            const botMessageDiv = document.createElement('div');
            botMessageDiv.className = 'chat-message bot-message';
            botMessageDiv.innerHTML = `<p>${data.response}</p>`;
            chatBody.appendChild(botMessageDiv);

            // Scroll to bottom
            chatBody.scrollTop = chatBody.scrollHeight;

        } catch (error) {
            console.error('Error sending message:', error);
            const errorDiv = document.createElement('div');
            errorDiv.className = 'chat-message bot-message';
            errorDiv.innerHTML = '<p>Sorry, I encountered an error. Please try again.</p>';
            chatBody.appendChild(errorDiv);
        }
    }

    if (sendChatBtn) {
        sendChatBtn.addEventListener('click', sendMessage);
    }

    if (chatInput) {
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }

    // Add smooth scroll to all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});
