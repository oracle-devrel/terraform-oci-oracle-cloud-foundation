import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "your-secret-key-change-in-production")

    # Document backend
    MONGO_URI = os.environ.get("MONGO_URI", "").strip()
    MONGO_DBNAME = os.environ.get("MONGO_DBNAME", "").strip()
    DOCUMENT_BACKEND = os.environ.get("DOCUMENT_BACKEND", "disabled").strip()
    DB_ENV = os.environ.get("DB_ENV", "oracle_sql").strip()

    # Oracle
    ORACLE_USER = os.environ.get("ORACLE_USER", "ADMIN").strip()
    ORACLE_PASSWORD = os.environ.get("ORACLE_PASSWORD", "").strip()
    ORACLE_DSN = os.environ.get("ORACLE_DSN", "").strip()
    ORACLE_WALLET_LOCATION = os.environ.get("ORACLE_WALLET_LOCATION", "").strip()
    TNS_ADMIN = os.environ.get("TNS_ADMIN", "").strip()

    ITEMS_PER_PAGE = 12
    MAX_UPLOAD_SIZE = 16 * 1024 * 1024