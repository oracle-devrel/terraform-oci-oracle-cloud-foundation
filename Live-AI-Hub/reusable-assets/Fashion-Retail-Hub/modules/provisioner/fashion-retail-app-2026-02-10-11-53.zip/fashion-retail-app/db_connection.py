import os

import oracledb
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

_ORACLE_CLIENT_INITIALIZED = False


def mongo_enabled_by_env():
    mongo_uri = os.getenv("MONGO_URI", "").strip()
    mongo_dbname = os.getenv("MONGO_DBNAME", "").strip()
    return bool(mongo_uri and mongo_dbname)


def get_mongo_db():
    """Return Mongo-compatible database or None if disabled."""
    mongo_uri = os.getenv("MONGO_URI", "").strip()
    mongo_dbname = os.getenv("MONGO_DBNAME", "").strip()

    if not mongo_uri or not mongo_dbname:
        print("Mongo-compatible backend disabled - skipping document connection")
        return None

    try:
        print("####### MONGO_URI: " + mongo_uri)
        print("####### MONGO_DBNAME: " + mongo_dbname)

        client = MongoClient(
            mongo_uri,
            serverSelectionTimeoutMS=5000,
            connectTimeoutMS=10000,
            retryWrites=False,
        )
        client.admin.command("ping")
        db = client[mongo_dbname]

        print(f"Successfully connected to Mongo-compatible backend: {mongo_dbname}")
        return db
    except Exception as e:
        print(f"Error connecting to Mongo-compatible backend: {e}")
        return None


def _init_oracle_client_if_needed(wallet_location: str):
    global _ORACLE_CLIENT_INITIALIZED

    if _ORACLE_CLIENT_INITIALIZED:
        return

    try:
        oracledb.init_oracle_client(
            lib_dir="/usr/lib/oracle/21/client64/lib",
            config_dir=wallet_location if wallet_location else None,
        )
        _ORACLE_CLIENT_INITIALIZED = True
    except Exception:
        pass


def oracle_env_configured():
    user = os.getenv("ORACLE_USER", "").strip()
    password = os.getenv("ORACLE_PASSWORD", "").strip()
    dsn = os.getenv("ORACLE_DSN", "").strip()
    return bool(user and password and dsn)


def get_oracle_connection():
    """Create Oracle connection using wallet. Raises only if explicitly used and config is invalid."""
    user = os.getenv("ORACLE_USER", "").strip()
    password = os.getenv("ORACLE_PASSWORD", "").strip()
    dsn = os.getenv("ORACLE_DSN", "").strip()
    wallet_location = os.getenv("ORACLE_WALLET_LOCATION", "").strip()
    tns_admin = os.getenv("TNS_ADMIN", "").strip()

    if not user or not password or not dsn:
        raise RuntimeError("Oracle runtime is not configured")

    if wallet_location:
        if not tns_admin:
            tns_admin = wallet_location
        os.environ["TNS_ADMIN"] = tns_admin
        _init_oracle_client_if_needed(wallet_location)

    print("####### ORACLE_WALLET_LOCATION: " + wallet_location)
    print("####### ORACLE_USER: " + user)
    print("####### ORACLE_DSN: " + dsn)
    print("####### TNS_ADMIN: " + tns_admin)

    connection = oracledb.connect(
        user=user,
        password=password,
        dsn=dsn,
        config_dir=wallet_location if wallet_location else None,
    )

    print("Successfully connected to Oracle Autonomous Database")
    return connection


if __name__ == "__main__":
    print("Testing Mongo-compatible backend connection...")
    db = get_mongo_db()
    if db is not None:
        print(f"Collections: {db.list_collection_names()}")
    else:
        print("Mongo-compatible backend disabled or unavailable")

    print("")
    print("Testing Oracle connection...")
    if oracle_env_configured():
        conn = get_oracle_connection()
        conn.close()
        print("Oracle connection OK")
    else:
        print("Oracle runtime not configured")